# -*- coding: utf-8 -*-
"""
states.py - Maquina de estados finitos para Frecuencia 1920
Incluye logica de cada nivel, hotspots, mini-juegos y transiciones
"""
import pygame
import random
import math
import os
from ui import Button, SignalBar, Modal, draw_hotspot, draw_top_bar, get_font, wrap_text, CREAM, GOLD, SEPIA_DARK, NEGRO
from questions import PREGUNTAS, CARTAS_TELETIPO, HOTSPOTS_DATA

WIDTH, HEIGHT = 1024, 768

# Estados
MENU_INICIAL = 0
NIVEL_1 = 1
NIVEL_2 = 2
NIVEL_3 = 3
NIVEL_4 = 4
VICTORIA = 5
GAME_OVER = 6
SPLASH = 7
CREDITS = 8

TITULOS_NIVEL = {
    1: "Laboratorio de Válvulas",
    2: "Azotea del Teatro Coliseo",
    3: "Sala de Redacción KDKA",
    4: "Receptor de Galena",
}

# --- Logo / Marca de agua helpers ---
_LOGO_CACHE = {}
_LOGO_MINI_CACHE = {}

def get_logo(size=None):
    """Carga logo.png con cache, opcional escalado"""
    key = size if size else "orig"
    if key in _LOGO_CACHE:
        return _LOGO_CACHE[key]
    # intentar logo.png y luego logo_mini.png como fallback
    img = None
    for name in ["logo.png", "logo_mini.png"]:
        try:
            p = resource_path(os.path.join("assets", "images", name))
            if os.path.exists(p):
                img = pygame.image.load(p).convert_alpha()
                break
        except:
            continue
    if img is None:
        # placeholder: circulo JO
        s = 200
        img = pygame.Surface((s,s), pygame.SRCALPHA)
        pygame.draw.circle(img, (25,20,15), (s//2,s//2), 90)
        pygame.draw.circle(img, (180,150,80), (s//2,s//2), 86, 3)
        f = get_font(52, bold=True)
        t = f.render("JO", True, (180,150,80))
        img.blit(t, (s//2 - t.get_width()//2, s//2 - t.get_height()//2))
    if size:
        img = pygame.transform.smoothscale(img, size)
    _LOGO_CACHE[key] = img
    return img

def draw_watermark(surf, alpha=52):
    """Marca de agua 20% opacidad en esquina inferior derecha"""
    try:
        logo = get_logo((28,28))
        # aplicar alpha 20%
        wm = logo.copy()
        wm.set_alpha(alpha)
        x = WIDTH - 28 - 12 - 220  # espacio para texto
        y = HEIGHT - 28 - 10
        surf.blit(wm, (x, y))
        # texto
        font = get_font(10, italic=True)
        txt = font.render("Creado por Jeison Ortiz O. | Proyecto Radiofónico", True, (200,185,150))
        # fondo sutil
        bg = pygame.Surface((txt.get_width()+8, 18), pygame.SRCALPHA)
        bg.fill((15,12,10, 110))
        surf.blit(bg, (x+34, y+6))
        # texto con alpha similar
        txt.set_alpha(min(255, alpha+90))
        surf.blit(txt, (x+38, y+7))
    except Exception as e:
        # fallback sin logo
        try:
            font = get_font(10, italic=True)
            txt = font.render("Creado por Jeison Ortiz O. | Proyecto Radiofónico", True, (200,185,150, alpha))
            surf.blit(txt, (WIDTH - txt.get_width() - 12, HEIGHT - 18))
        except:
            pass

def resource_path(relative):
    """Resuelve assets en: desarrollo, PyInstaller (onedir/onefile) y Pygbag (wasm)"""
    import sys
    candidates = []
    # 1. PyInstaller _MEIPASS
    try:
        base = sys._MEIPASS  # type: ignore
        candidates.append(os.path.join(base, relative))
        candidates.append(os.path.join(os.path.dirname(base), relative))
        exe_dir = os.path.dirname(sys.executable) if getattr(sys, 'frozen', False) else None
        if exe_dir:
            candidates.append(os.path.join(exe_dir, relative))
            candidates.append(os.path.join(exe_dir, "_internal", relative))
    except Exception:
        pass
    # 2. Desarrollo y Pygbag: bases relativas a __file__
    try:
        file_dir = os.path.dirname(os.path.abspath(__file__))
        # pygbag: __file__ = /data/data/src/assets/main.py  -> file_dir = .../assets
        candidates.append(os.path.join(file_dir, relative))  # src/assets case (wasm single en loaderhome)
        candidates.append(os.path.join(file_dir, os.path.basename(relative.split("/")[0]), *relative.split("/")[1:]) if "/" in relative else os.path.join(file_dir, relative))
        # dev: un nivel arriba de src (project root)
        dev_base = os.path.abspath(os.path.join(file_dir, ".."))
        candidates.append(os.path.join(dev_base, relative))
        # wasm double assets: appdir/assets/assets/...
        candidates.append(os.path.join(file_dir, relative))  # already
        candidates.append(os.path.join(dev_base, relative))
        # cwd variants
        cwd = os.path.abspath(".")
        candidates.append(os.path.join(cwd, relative))
        candidates.append(os.path.join(cwd, "assets", *relative.split("/")[1:]) if relative.startswith("assets/") else os.path.join(cwd, relative))
        # pygbag double: assets/assets/...
        if relative.startswith("assets/"):
            # si relative es assets/images/x, probar assets/assets/images/x desde file_dir y cwd
            double = os.path.join("assets", relative)
            candidates.append(os.path.join(file_dir, double))
            candidates.append(os.path.join(dev_base, double))
            candidates.append(os.path.join(cwd, double))
            # tambien desde appdir (2 niveles arriba de file_dir en wasm: /data/data/src)
            appdir = os.path.abspath(os.path.join(file_dir, ".."))
            candidates.append(os.path.join(appdir, relative))
            candidates.append(os.path.join(appdir, double))
            candidates.append(os.path.join(appdir, "assets", relative))
        # src/assets variant (cuando app_folder=src)
        candidates.append(os.path.join(dev_base, "src", relative))
        candidates.append(os.path.join(cwd, "src", relative))
    except Exception:
        pass
    # Probar en orden y devolver primero existente, sino devolver primero candidato (para mensaje de error)
    for cand in candidates:
        try:
            if os.path.exists(cand):
                return cand
        except:
            continue
    # fallback: intentar dev_base
    try:
        return os.path.join(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")), relative)
    except:
        return relative

def load_img(name, size=None):
    path = resource_path(os.path.join("assets", "images", name))
    try:
        img = pygame.image.load(path).convert_alpha()
        if size:
            img = pygame.transform.smoothscale(img, size)
        return img
    except Exception as e:
        print(f"WARN no se pudo cargar imagen {name}: {e}")
        surf = pygame.Surface(size or (100,100), pygame.SRCALPHA)
        surf.fill((80,70,60, 180))
        return surf

def load_sound(name, volume=0.6):
    path = resource_path(os.path.join("assets", "audio", name))
    # probar .wav y .mp3
    candidates = [path, path.replace(".mp3",".wav"), path.replace(".wav",".mp3")]
    for p in candidates:
        if os.path.exists(p):
            try:
                s = pygame.mixer.Sound(p)
                s.set_volume(volume)
                return s
            except Exception as e:
                print(f"WARN sonido {p}: {e}")
    # dummy
    class Dummy:
        def play(self): pass
        def set_volume(self, v): pass
        def stop(self): pass
    return Dummy()

class BaseState:
    def __init__(self, game):
        self.game = game
    def enter(self): pass
    def exit(self): pass
    def handle_event(self, event): pass
    def update(self, dt, mouse_pos): pass
    def draw(self, surf): pass

# ---------- SPLASH ----------
class SplashState(BaseState):
    """Pantalla de inicio 3s con fade-in/out del logo"""
    def __init__(self, game):
        super().__init__(game)
        self.t = 0
        self.duration = 3.0
        self.logo = None
        self.bg = None

    def enter(self):
        self.t = 0
        # fondo negro/sepia ya se dibuja en draw, no necesita imagen
        # precargar logo grande 260x260
        try:
            self.logo = get_logo((260, 260))
        except:
            self.logo = None
        # intentar musica ya en menu, no aqui

    def handle_event(self, event):
        # permitir skip con cualquier click o tecla
        if event.type == pygame.MOUSEBUTTONDOWN or event.type == pygame.KEYDOWN:
            # ESC también va a menú, cualquier tecla skip
            self.game.change_state(MENU_INICIAL)

    def update(self, dt, mouse_pos):
        self.t += dt
        if self.t >= self.duration:
            self.game.change_state(MENU_INICIAL)

    def draw(self, surf):
        # fondo negro/sepia degradado vintage
        # degradado vertical de negro a sepia oscuro
        for y in range(HEIGHT):
            t = y / HEIGHT
            r = int(10 + t*25)
            g = int(8 + t*18)
            b = int(6 + t*12)
            pygame.draw.line(surf, (r,g,b), (0,y), (WIDTH,y))
        # viñeteo sutil
        vign = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
        for i in range(80):
            alpha = int(140 * (1 - i/80)**2)
            # dibujar borde con rect
        # calcular alpha fade: 0-0.8s fade in, 0.8-2.2 hold, 2.2-3.0 fade out
        if self.t < 0.8:
            alpha = int(255 * (self.t / 0.8))
        elif self.t < 2.2:
            alpha = 255
        else:
            alpha = int(255 * (1 - (self.t - 2.2) / 0.8))
            alpha = max(0, min(255, alpha))
        # logo centrado con alpha
        if self.logo:
            logo_surf = self.logo.copy()
            logo_surf.set_alpha(alpha)
            # sombra suave
            shadow = pygame.Surface((280,280), pygame.SRCALPHA)
            pygame.draw.circle(shadow, (0,0,0, 60), (140,140), 140)
            shadow.set_alpha(alpha//3)
            surf.blit(shadow, (WIDTH//2 - 140 + 4, HEIGHT//2 - 160 + 4))
            surf.blit(logo_surf, (WIDTH//2 - logo_surf.get_width()//2, HEIGHT//2 - 150 - logo_surf.get_height()//2))
        # texto vintage debajo
        font_main = get_font(16, italic=True)
        font_sub = get_font(11)
        txt1 = font_main.render("Un desarrollo conceptual e interactivo de", True, (200,185,150))
        txt2 = get_font(22, bold=True).render("Jeison Ortiz Ortiz", True, GOLD)
        # aplicar alpha al texto via surface?
        # crear surfaces con alpha
        for txt, yoff, col in [(txt1, 110, (200,185,150)), (txt2, 135, GOLD)]:
            # recrear con alpha
            tmp = pygame.Surface(txt.get_size(), pygame.SRCALPHA)
            tmp.blit(txt, (0,0))
            tmp.set_alpha(alpha)
            surf.blit(tmp, (WIDTH//2 - txt.get_width()//2, HEIGHT//2 + yoff))
        # barra de progreso sutil 3s
        bar_w = 320
        bar = pygame.Rect(WIDTH//2 - bar_w//2, HEIGHT - 90, bar_w, 4)
        pygame.draw.rect(surf, (60,50,35), bar, border_radius=2)
        progress = max(0, min(1, self.t / self.duration))
        fill = pygame.Rect(bar.x, bar.y, int(bar_w * progress), bar.height)
        pygame.draw.rect(surf, GOLD, fill, border_radius=2)
        # texto skip
        if self.t > 0.5:
            skip_alpha = int(min(255, alpha*0.6))
            skip = get_font(10).render("Haz clic o pulsa cualquier tecla para continuar", True, (160,145,120))
            skip.set_alpha(skip_alpha)
            surf.blit(skip, (WIDTH//2 - skip.get_width()//2, HEIGHT - 60))
        # watermark sutil también en splash (más tenue)
        draw_watermark(surf, alpha=30)

# ---------- MENU ----------
class MenuState(BaseState):
    def __init__(self, game):
        super().__init__(game)
        self.bg = None
        self.title_font = None
        self.sub_font = None
        self.btn_jugar = None
        self.btn_salir = None
        self.btn_creditos = None
        self.show_creditos = False
        self.t = 0

    def enter(self):
        self.bg = load_img("fondo_menu.png", (WIDTH, HEIGHT))
        self.title_font = get_font(52, bold=True)
        self.sub_font = get_font(16, italic=True)
        # botones centrados
        self.btn_jugar = Button(pygame.Rect(WIDTH//2-140, 420, 280, 60), "SINTONIZAR  1920  ►", font=get_font(20, bold=True), base_color=(180,150,80), hover_color=(210,180,110))
        self.btn_salir = Button(pygame.Rect(WIDTH//2-140, 500, 280, 50), "SALIR", font=get_font(16, bold=True), base_color=(90,80,70), hover_color=(120,110,95), text_color=CREAM)
        self.btn_creditos = Button(pygame.Rect(WIDTH//2-140, 565, 280, 36), "CRÉDITOS  /  HISTORIA", font=get_font(12, bold=True), base_color=(55,50,45), hover_color=(75,70,65), text_color=(200,185,150))
        # intentar musica
        try:
            pygame.mixer.music.load(resource_path(os.path.join("assets","audio","musica_fondo.mp3")))
            pygame.mixer.music.set_volume(0.45)
            pygame.mixer.music.play(-1)
        except:
            try:
                pygame.mixer.music.load(resource_path(os.path.join("assets","audio","musica_fondo.wav")))
                pygame.mixer.music.set_volume(0.45)
                pygame.mixer.music.play(-1)
            except Exception as e:
                print(f"musica menu fail: {e}")

    def handle_event(self, event):
        if self.btn_jugar.is_clicked(event):
            try: load_sound("clic.wav",0.7).play()
            except: pass
            self.game.signal = 100
            self.game.nivel_actual = 1
            self.game.change_state(NIVEL_1)
        elif self.btn_creditos.is_clicked(event):
            try: load_sound("clic.wav",0.5).play()
            except: pass
            self.game.change_state(CREDITS)
        elif self.btn_salir.is_clicked(event):
            self.game.running = False
        if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
            self.game.running=False
        if event.type == pygame.KEYDOWN and event.key == pygame.K_c:
            self.game.change_state(CREDITS)

    def update(self, dt, mouse_pos):
        self.t += dt
        self.btn_jugar.update(mouse_pos)
        self.btn_salir.update(mouse_pos)
        self.btn_creditos.update(mouse_pos)

    def draw(self, surf):
        surf.blit(self.bg, (0,0))
        # overlay central para titulo
        # panel vintage
        panel = pygame.Rect(WIDTH//2 - 360, 60, 720, 300)
        # sombra
        shadow = panel.copy(); shadow.x+=5; shadow.y+=5
        pygame.draw.rect(surf, (0,0,0, 90), shadow, border_radius=16)
        pygame.draw.rect(surf, (25,20,15), panel, border_radius=16)
        inner = panel.inflate(-6,-6)
        pygame.draw.rect(surf, (245,235,210), inner, border_radius=14)
        pygame.draw.rect(surf, GOLD, inner, 3, border_radius=14)
        # decorativo
        pygame.draw.line(surf, GOLD, (inner.x+30, inner.y+60), (inner.right-30, inner.y+60), 1)
        pygame.draw.line(surf, GOLD, (inner.x+30, inner.bottom-40), (inner.right-30, inner.bottom-40), 1)
        # titulo con efecto
        # FRECUENCIA
        # sombra texto
        f1 = get_font(52, bold=True)
        f2 = get_font(20, bold=True)
        title1 = f1.render("FRECUENCIA", True, (45,30,15))
        # centrar
        surf.blit(title1, (WIDTH//2 - title1.get_width()//2 + 2, 82+2))
        title1_gold = f1.render("FRECUENCIA", True, (160,130,70))
        surf.blit(title1_gold, (WIDTH//2 - title1_gold.get_width()//2, 82))
        # 1920 grande
        f_big = get_font(72, bold=True)
        t1920 = f_big.render("1920", True, (180,50,40))
        surf.blit(t1920, (WIDTH//2 - t1920.get_width()//2, 142))
        # subtitulo
        sub = get_font(14, italic=True).render("Una aventura Point & Click  •  La revolución de la radio", True, (90,80,65))
        surf.blit(sub, (WIDTH//2 - sub.get_width()//2, 225))
        # dial animado
        cx, cy = WIDTH//2, 300
        # linea frecuencia
        pygame.draw.rect(surf, (45,38,28), (cx-220, cy-10, 440, 22), border_radius=8)
        pygame.draw.rect(surf, GOLD, (cx-220, cy-10, 440, 22), 1, border_radius=8)
        # escala
        for i in range(11):
            x = cx-200 + i*40
            h = 12 if i%2==0 else 6
            pygame.draw.line(surf, GOLD, (x, cy-6), (x, cy-6+h), 1)
            if i%2==0:
                lbl = get_font(8).render(f"{550+i*100}", True, GOLD)
                surf.blit(lbl, (x - lbl.get_width()//2, cy+8))
        # aguja oscilante
        aguja_x = cx - 120 + int(80*math.sin(self.t*0.6)) + int(40*math.sin(self.t*1.7))
        pygame.draw.polygon(surf, (220,50,50), [(aguja_x, cy-14),(aguja_x-6, cy+6),(aguja_x+6, cy+6)])
        pygame.draw.line(surf, (220,50,50), (aguja_x, cy-14),(aguja_x, cy+6),2)
        # luz
        pygame.draw.circle(surf, (80,255,90), (cx+200, cy), 6)
        pygame.draw.circle(surf, (140,255,150), (cx+200, cy), 3)
        # version
        ver = get_font(10).render("v1.0  •  Python + Pygame  •  1024x768  •  60 FPS", True, (140,130,115))
        surf.blit(ver, (WIDTH//2 - ver.get_width()//2, 340))
        # botones
        self.btn_jugar.draw(surf)
        self.btn_salir.draw(surf)
        self.btn_creditos.draw(surf)
        # tip abajo
        tip = get_font(11).render("Haz clic en los objetos brillantes para descubrir la historia. ¡Cuida tu SEÑAL!", True, (200,185,150))
        # fondo tip
        tip_bg = pygame.Rect(WIDTH//2 - tip.get_width()//2 -12, 620, tip.get_width()+24, 22)
        pygame.draw.rect(surf, (15,12,10, 140), tip_bg, border_radius=6)
        surf.blit(tip, (WIDTH//2 - tip.get_width()//2, 624))
        # marca de agua vintage
        draw_watermark(surf, alpha=52)

# ---------- CREDITOS / AUTORIA ----------
class CreditsState(BaseState):
    def __init__(self, game):
        super().__init__(game)
        self.bg = None
        self.btn_volver = None
        self.t = 0
        self.logo = None

    def enter(self):
        self.bg = load_img("fondo_menu.png", (WIDTH, HEIGHT))
        self.btn_volver = Button(pygame.Rect(WIDTH//2 - 110, HEIGHT - 58, 220, 44), "◀  VOLVER AL MENÚ", font=get_font(14, bold=True), base_color=GOLD, hover_color=(210,180,110))
        self.t = 0
        try:
            self.logo = get_logo((180, 180))
        except:
            self.logo = None

    def handle_event(self, event):
        if self.btn_volver.is_clicked(event):
            try: load_sound("clic.wav",0.5).play()
            except: pass
            self.game.change_state(MENU_INICIAL)
        if event.type == pygame.KEYDOWN and event.key in (pygame.K_ESCAPE, pygame.K_BACKSPACE):
            self.game.change_state(MENU_INICIAL)
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            # click fuera también vuelve si es en borde
            pass

    def update(self, dt, mouse_pos):
        self.t += dt
        self.btn_volver.update(mouse_pos)

    def draw(self, surf):
        surf.blit(self.bg, (0,0))
        # overlay oscuro para contraste
        over = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
        over.fill((0,0,0, 130))
        surf.blit(over, (0,0))
        # panel principal estilo cartelera cine mudo / periódico 1920
        panel = pygame.Rect(WIDTH//2 - 380, 22, 760, 700)
        shadow = panel.copy(); shadow.x+=6; shadow.y+=6
        pygame.draw.rect(surf, (0,0,0, 90), shadow, border_radius=14)
        pygame.draw.rect(surf, (25,20,15), panel, border_radius=14)
        inner = panel.inflate(-8,-8)
        pygame.draw.rect(surf, (245,235,210), inner, border_radius=12)
        # doble borde
        pygame.draw.rect(surf, GOLD, inner, 3, border_radius=12)
        inner2 = inner.inflate(-10,-10)
        pygame.draw.rect(surf, (180,150,90, 70), inner2, 1, border_radius=10)
        # líneas decorativas superior/inferior
        pygame.draw.line(surf, GOLD, (inner.x+20, inner.y+22), (inner.right-20, inner.y+22), 1)
        pygame.draw.line(surf, GOLD, (inner.x+20, inner.bottom-22), (inner.right-20, inner.bottom-22), 1)
        # esquinas ornamentales
        for cx, cy in [(inner.x+12, inner.y+12), (inner.right-12, inner.y+12), (inner.x+12, inner.bottom-12), (inner.right-12, inner.bottom-12)]:
            pygame.draw.circle(surf, GOLD, (cx,cy), 4)
            pygame.draw.circle(surf, (245,235,210), (cx,cy), 2)
        # logo centrado superior
        if self.logo:
            # sombra logo
            sh = pygame.Surface((190,190), pygame.SRCALPHA)
            pygame.draw.circle(sh, (0,0,0, 50), (95,95), 90)
            surf.blit(sh, (panel.centerx - 95, inner.y+28))
            surf.blit(self.logo, (panel.centerx - self.logo.get_width()//2, inner.y+32))
            y_start = inner.y + 222
        else:
            y_start = inner.y + 40
        # título ficha
        title = get_font(20, bold=True).render("FICHA TÉCNICA Y DERECHOS DE AUTOR", True, SEPIA_DARK)
        surf.blit(title, (panel.centerx - title.get_width()//2, y_start))
        y_start += 26
        sub = get_font(11, italic=True).render("Cartelera de Cine Mudo  —  Periódico de 1920  —  Proyecto Radiofónico", True, (120,110,90))
        surf.blit(sub, (panel.centerx - sub.get_width()//2, y_start))
        y_start += 18
        pygame.draw.line(surf, GOLD, (panel.centerx-200, y_start), (panel.centerx+200, y_start), 1)
        y_start += 14
        # Datos ficha en dos columnas / lista elegante
        ficha = [
            ("Diseño y Desarrollo:", "Jeison Ortiz Ortiz"),
            ("Edad:", "26 años"),
            ("Ubicación:", "Cali, Colombia"),
            ("Institución:", "Institución Universitaria Antonio José Camacho"),
            ("Carrera:", "Comunicación Social"),
            ("Asignatura:", "Proyecto Radiofónico (Primer Parcial / Proyecto Final)"),
            ("Año de producción:", "2026"),
            ("Licencia:", "Todos los derechos reservados © 2026 - Jeison Ortiz Ortiz"),
        ]
        # fondo de ficha tipo papel envejecido
        ficha_bg = pygame.Rect(inner.x+22, y_start, inner.width-44, 360)
        pygame.draw.rect(surf, (255,250,235), ficha_bg, border_radius=8)
        pygame.draw.rect(surf, (180,150,90), ficha_bg, 1, border_radius=8)
        # líneas horizontales sutiles tipo renglón
        for i in range(1, 10):
            ly = ficha_bg.y + 32 + i*30
            pygame.draw.line(surf, (230,215,185), (ficha_bg.x+18, ly), (ficha_bg.right-18, ly), 1)
        y = ficha_bg.y + 18
        for label, value in ficha:
            # label bold
            lbl_surf = get_font(12, bold=True).render(label, True, SEPIA_DARK)
            val_surf = get_font(12).render(value, True, (60,50,35))
            # sangría
            surf.blit(lbl_surf, (ficha_bg.x+22, y))
            # si el value es largo, wrap
            if val_surf.get_width() > ficha_bg.width - lbl_surf.get_width() - 30:
                # dos líneas
                val_surf = get_font(11).render(value, True, (60,50,35))
                surf.blit(val_surf, (ficha_bg.x+22, y+16))
                y += 34
            else:
                surf.blit(val_surf, (ficha_bg.x+24 + lbl_surf.get_width(), y))
                y += 30
        # sello vintage esquina
        sello_r = pygame.Rect(ficha_bg.right - 92, ficha_bg.y + ficha_bg.height - 92, 82, 82)
        pygame.draw.circle(surf, (180,50,40, 26), sello_r.center, 38)
        pygame.draw.circle(surf, (180,50,40), sello_r.center, 36, 2)
        sello_txt = get_font(9, bold=True).render("1920", True, (180,50,40))
        surf.blit(sello_txt, (sello_r.centerx - sello_txt.get_width()//2, sello_r.centery - 14))
        sello2 = get_font(7).render("ORIGINAL", True, (180,50,40))
        surf.blit(sello2, (sello_r.centerx - sello2.get_width()//2, sello_r.centery + 4))
        # pie vintage
        foot = get_font(10, italic=True).render("Un desarrollo conceptual e interactivo de Jeison Ortiz Ortiz  •  Cali 2026", True, (110,100,85))
        surf.blit(foot, (panel.centerx - foot.get_width()//2, ficha_bg.bottom + 10))
        # botón volver
        self.btn_volver.draw(surf)
        # marca de agua también aquí pero muy sutil
        draw_watermark(surf, alpha=32)

# ---------- NIVEL BASE ----------
class NivelState(BaseState):
    def __init__(self, game, nivel_num):
        super().__init__(game)
        self.nivel = nivel_num
        self.bg = None
        self.hotspots = []  # lista de dict {rect, id, nombre}
        self.signal_bar = SignalBar(pygame.Rect(0,0,260,18), value=game.signal)
        self.modal = None
        self.show_modal = False
        self.pregunta_data = PREGUNTAS[nivel_num]
        self.completado = False
        self.hotspot_hover = None
        # sonidos
        self.snd_click = None
        self.snd_ok = None
        self.snd_err = None
        self.t = 0
        # para feedback visual
        self.flash_timer = 0
        self.flash_color = None

    def enter(self):
        self.bg = load_img(f"fondo_nivel{self.nivel}.png", (WIDTH, HEIGHT))
        self.snd_click = load_sound("clic.wav", 0.7)
        self.snd_ok = load_sound("acierto.wav", 0.7)
        self.snd_err = load_sound("error.wav", 0.7)
        self.signal_bar.set_value(self.game.signal)
        self.signal_bar.anim = float(self.game.signal)
        self.completado = False
        self.show_modal = False
        self.modal = None
        self._setup_hotspots()

    def _setup_hotspots(self):
        # por defecto: 3 hotspots genericos; hijos sobreescriben
        pass

    def _trigger_question(self):
        if self.show_modal: return
        self.modal = Modal(self.pregunta_data)
        self.show_modal = True

    def handle_event(self, event):
        if self.show_modal and self.modal:
            res = self.modal.handle_event(event, pygame.mouse.get_pos())
            if res == "correct":
                try: self.snd_ok.play()
                except: pass
                self.flash_timer = 30
                self.flash_color = (70,150,70)
            elif res == "incorrect":
                try: self.snd_err.play()
                except: pass
                # penalizacion
                self.game.signal = max(0, self.game.signal - 20)
                self.signal_bar.set_value(self.game.signal)
                self.flash_timer = 40
                self.flash_color = (190,60,60)
                if self.game.signal <= 0:
                    # pequeño delay antes de game over para ver feedback
                    self._pending_game_over = True
                else:
                    self._pending_game_over = False
            elif res == "continue":
                # cerrar modal y avanzar o quedarse
                self.show_modal = False
                if getattr(self, "_pending_game_over", False):
                    self.game.change_state(GAME_OVER)
                    return
                if self.modal.result == "correct":
                    self.on_correct_answer()
                else:
                    # si falló pero aun tiene señal, puede reintentar
                    # cerramos modal y permitimos volver a intentar hotspots
                    self.modal = None
                    # opcional: mantener hotspot deshabilitado? no, permitir reintento
                    pass
                self.modal = None
            return

        if event.type == pygame.MOUSEBUTTONDOWN and event.button==1:
            mp = event.pos
            # primero verificar top bar? no
            for hs in self.hotspots:
                if hs["rect"].collidepoint(mp):
                    try: self.snd_click.play()
                    except: pass
                    self.on_hotspot_click(hs["id"])
                    break

    def on_hotspot_click(self, hs_id):
        # por defecto activar pregunta
        self._trigger_question()

    def on_correct_answer(self):
        # transicion al siguiente nivel
        self.completado = True
        # pequeño efecto
        self.flash_timer = 20
        self.flash_color = (70,150,70)
        # delay? directo
        if self.nivel < 4:
            self.game.change_state(self.nivel+1)  # NIVEL_1=1 etc mapeo directo
        else:
            self.game.change_state(VICTORIA)

    def update(self, dt, mouse_pos):
        self.t += dt
        self.signal_bar.update()
        if self.show_modal and self.modal:
            self.modal.update(mouse_pos)
        else:
            # hover hotspots
            self.hotspot_hover = None
            for hs in self.hotspots:
                if hs["rect"].collidepoint(mouse_pos):
                    self.hotspot_hover = hs["id"]
                    break
        if self.flash_timer>0:
            self.flash_timer -=1

    def draw(self, surf):
        surf.blit(self.bg, (0,0))
        # hotspots
        for hs in self.hotspots:
            hovered = (hs["id"]==self.hotspot_hover) and not self.show_modal
            draw_hotspot(surf, hs["rect"], hs["nombre"], hovered=hovered, font=get_font(12, bold=True))
            # descripcion al hover (debajo)
            if hovered:
                desc = hs.get("desc","")
                if desc:
                    lines = wrap_text(desc, get_font(11), 300)
                    # caja desc
                    w = max(get_font(11).size(l)[0] for l in lines) + 20 if lines else 0
                    h = len(lines)*14 + 16
                    box = pygame.Rect(hs["rect"].centerx - w//2, hs["rect"].bottom+8, w, h)
                    # evitar fuera de pantalla
                    box.x = max(6, min(WIDTH - w -6, box.x))
                    box.y = min(HEIGHT - h -10, box.y)
                    pygame.draw.rect(surf, (25,20,15), box, border_radius=6)
                    inner = box.inflate(-4,-4)
                    pygame.draw.rect(surf, (245,235,205), inner, border_radius=5)
                    for i, line in enumerate(lines):
                        ls = get_font(11).render(line, True, SEPIA_DARK)
                        surf.blit(ls, (inner.centerx - ls.get_width()//2, inner.y+6 + i*14))
        # top bar
        draw_top_bar(surf, self.nivel, TITULOS_NIVEL[self.nivel], self.signal_bar, font=get_font(15, bold=True))
        # instrucciones abajo
        instr = get_font(11).render("Haz clic en un objeto brillante para inspeccionar.  Encuentra el objeto CLAVE.", True, (220,210,180))
        bg_instr = pygame.Surface((instr.get_width()+24, 22), pygame.SRCALPHA)
        bg_instr.fill((15,12,10, 160))
        surf.blit(bg_instr, (WIDTH//2 - instr.get_width()//2 -12, HEIGHT-32))
        surf.blit(instr, (WIDTH//2 - instr.get_width()//2, HEIGHT-28))
        # flash
        if self.flash_timer>0 and self.flash_color:
            alpha = int(90 * (self.flash_timer/40))
            f = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
            f.fill((*self.flash_color, alpha))
            surf.blit(f,(0,0))
        # marca de agua en niveles (20% opacidad)
        if not self.show_modal:
            draw_watermark(surf, alpha=38)
        # modal
        if self.show_modal and self.modal:
            self.modal.draw(surf)

# ---------- NIVELES ESPECIFICOS ----------
class Nivel1State(NivelState):
    def __init__(self, game):
        super().__init__(game, 1)
    def _setup_hotspots(self):
        self.hotspots = [
            {"rect": pygame.Rect(60, 560, 220, 62), "id": "chispa", "nombre": "Transmisor de Chispas", "desc": HOTSPOTS_DATA[1][0]["desc"]},
            {"rect": pygame.Rect(400, 560, 220, 62), "id": "audion", "nombre": "★ VÁLVULA AUDIÓN ★", "desc": HOTSPOTS_DATA[1][1]["desc"]},
            {"rect": pygame.Rect(740, 560, 220, 62), "id": "antena", "nombre": "Antena Exterior", "desc": HOTSPOTS_DATA[1][2]["desc"]},
        ]
    def on_hotspot_click(self, hs_id):
        if hs_id == "audion":
            self._trigger_question()
        elif hs_id == "chispa":
            # feedback sin pregunta: pista
            self._show_hint("Ese transmisor solo hace 'chasquidos'. La voz necesita amplificación continua. Prueba la VÁLVULA.")
        else:
            self._show_hint("La antena está lista, pero sin el corazón correcto no emitirá voz. Busca la VÁLVULA.")
    def _show_hint(self, text):
        # modal temporal de pista (usamos modal simple improvisado)
        # en vez de modal pregunta, creamos un modal pista con un boton
        # reutilizamos show_modal con un Modal falso? mejor overlay simple temporizado
        self.hint_text = text
        self.hint_timer = 180  # 3 seg
        try: load_sound("estatica.wav",0.45).play()
        except: pass
    def update(self, dt, mouse_pos):
        super().update(dt, mouse_pos)
        if hasattr(self, "hint_timer") and self.hint_timer>0:
            self.hint_timer -=1
    def draw(self, surf):
        super().draw(surf)
        # dibujar circuito animado en centro si no modal
        if not self.show_modal:
            # esquema circuito
            cx, cy = WIDTH//2, 360
            # fondo esquema
            scheme = pygame.Rect(cx-280, cy-90, 560, 170)
            pygame.draw.rect(surf, (245,235,210, 210), scheme, border_radius=10)
            pygame.draw.rect(surf, GOLD, scheme, 2, border_radius=10)
            title = get_font(13, bold=True).render("ESQUEMA  DEL  TRANSMISOR  —  Selecciona el componente clave", True, SEPIA_DARK)
            surf.blit(title, (cx - title.get_width()//2, cy-82))
            # dibujar simbolos: bateria, audion, antena
            # bateria
            pygame.draw.rect(surf, (60,60,62), (cx-210, cy-20, 50, 36), border_radius=3)
            pygame.draw.rect(surf, (200,50,50), (cx-210, cy-20, 16, 36))
            pygame.draw.rect(surf, (50,50,55), (cx-160, cy-8, 28, 12))
            lbl = get_font(9).render("BATERÍA", True, SEPIA_DARK)
            surf.blit(lbl, (cx-210 +25 - lbl.get_width()//2, cy+22))
            # linea
            pygame.draw.line(surf, SEPIA_DARK, (cx-132, cy), (cx-80, cy), 2)
            # audion (circulo con filamento)
            # highlight si hover
            hover_audion = (self.hotspot_hover=="audion")
            col = (255, 220, 120) if hover_audion else (200,180,140)
            pygame.draw.circle(surf, col, (cx-40, cy), 36)
            pygame.draw.circle(surf, SEPIA_DARK, (cx-40, cy), 36, 2)
            # filamento
            pygame.draw.line(surf, (220,50,50), (cx-52, cy-12),(cx-28, cy+12),2)
            pygame.draw.line(surf, (220,50,50), (cx-28, cy-12),(cx-52, cy+12),2)
            pygame.draw.circle(surf, (255,240,150), (cx-40, cy), 6)
            if hover_audion:
                # brillo pulsante
                glow = int(60 + 40*math.sin(self.t*4))
                pygame.draw.circle(surf, (255,240,150, glow), (cx-40, cy), 44, 2)
            lbl2 = get_font(9, bold=True).render("AUDIÓN", True, SEPIA_DARK)
            surf.blit(lbl2, (cx-40 - lbl2.get_width()//2, cy+42))
            pygame.draw.line(surf, SEPIA_DARK, (cx-4, cy), (cx+50, cy), 2)
            # antena simbolo
            pygame.draw.line(surf, SEPIA_DARK, (cx+80, cy+30),(cx+80, cy-30),2)
            for off in [-18,-9,0,9,18]:
                pygame.draw.line(surf, SEPIA_DARK, (cx+80+off, cy-30),(cx+80, cy-38),1)
            lbl3 = get_font(9).render("ANTENA", True, SEPIA_DARK)
            surf.blit(lbl3, (cx+80 - lbl3.get_width()//2, cy+42))
            # indicador chispa tachado
            # chispas icon pequeño
            pygame.draw.circle(surf, (90,90,95), (cx+180, cy), 22)
            pygame.draw.circle(surf, SEPIA_DARK, (cx+180, cy), 22,2)
            # rayo
            pygame.draw.polygon(surf, (255,220,80), [(cx+175,cy-12),(cx+185,cy-2),(cx+178,cy-2),(cx+188,cy+12),(cx+178,cy+2),(cx+185,cy+2)])
            pygame.draw.line(surf, (190,60,60), (cx+168,cy-14),(cx+192,cy+14),3)
            lbl4 = get_font(9).render("CHISPAS", True, SEPIA_DARK)
            surf.blit(lbl4, (cx+180 - lbl4.get_width()//2, cy+42))
        # hint overlay
        if hasattr(self, "hint_timer") and self.hint_timer>0:
            alpha = min(255, self.hint_timer*3)
            box = pygame.Rect(WIDTH//2-300, 410, 600, 46)
            s = pygame.Surface((box.width, box.height), pygame.SRCALPHA)
            s.fill((45,30,15, 220))
            surf.blit(s, box.topleft)
            pygame.draw.rect(surf, GOLD, box, 2, border_radius=8)
            txt = get_font(13).render(self.hint_text, True, CREAM)
            surf.blit(txt, (WIDTH//2 - txt.get_width()//2, box.centery - txt.get_height()//2))

class Nivel2State(NivelState):
    def __init__(self, game):
        super().__init__(game, 2)
        self.dial_value = 50  # 0-100
        self.dial_target = 88  # valor correcto (88%)
        self.dial_dragging = False
        self.dial_solved = False
        self.slider_rect = pygame.Rect(212, 380, 600, 28)
        self.knob_rect = pygame.Rect(0,0,36,36)

    def _setup_hotspots(self):
        self.hotspots = [
            {"rect": pygame.Rect(60, 580, 200, 56), "id": "transmisor5w", "nombre": "Transmisor 5W", "desc": HOTSPOTS_DATA[2][0]["desc"]},
            {"rect": pygame.Rect(412, 580, 200, 56), "id": "dial", "nombre": "★ DIAL DE SINTONÍA ★", "desc": HOTSPOTS_DATA[2][2]["desc"]},
            {"rect": pygame.Rect(760, 580, 200, 56), "id": "microfono", "nombre": "Micrófono Carbón", "desc": HOTSPOTS_DATA[2][1]["desc"]},
        ]

    def on_hotspot_click(self, hs_id):
        if hs_id == "dial":
            # activar mini juego dial antes de pregunta? segun guion: slider interactivo donde posicionar aguja respondiendo acertijo
            # flujo: al click dial -> muestra slider; cuando slider en zona correcta -> dispara pregunta
            self.show_slider = True
        elif hs_id == "transmisor5w":
            self._show_hint("¡El transmisor está encendido y calienta! Ahora debes SINTONIZAR el dial con precisión.")
        else:
            self._show_hint("El micrófono cuelga sobre el foso de la orquesta. Pero sin sintonía fina, nadie oirá Parsifal.")

    def _show_hint(self, text):
        self.hint_text = text
        self.hint_timer = 180

    def enter(self):
        super().enter()
        self.show_slider = False
        self.dial_value = 42
        self.dial_solved = False
        self.hint_text = None
        self.hint_timer = 0

    def handle_event(self, event):
        # si modal pregunta activo -> delegar a base
        if self.show_modal:
            super().handle_event(event)
            return
        # slider interacción
        if getattr(self, "show_slider", False) and not self.dial_solved:
            if event.type == pygame.MOUSEBUTTONDOWN and event.button==1:
                if self.slider_rect.collidepoint(event.pos):
                    self.dial_dragging = True
                    self._update_dial_from_mouse(event.pos[0])
                # boton confirmar si en zona
                if hasattr(self, "btn_confirm_rect") and self.btn_confirm_rect.collidepoint(event.pos):
                    if abs(self.dial_value - self.dial_target) < 7:
                        self.dial_solved = True
                        try: load_sound("clic.wav",0.7).play()
                        except: pass
                        self._trigger_question()
                    else:
                        self.hint_text = "¡Aún hay mucha estática! Ajusta más cerca del 88% (zona verde)."
                        self.hint_timer = 150
                        try: load_sound("estatica.wav",0.5).play()
                        except: pass
            elif event.type == pygame.MOUSEBUTTONUP and event.button==1:
                self.dial_dragging = False
            elif event.type == pygame.MOUSEMOTION and self.dial_dragging:
                self._update_dial_from_mouse(event.pos[0])
            # también permitir click en hotspots del slider? pero si slider visible, hotspots siguen? priorizamos slider
            # si no esta dragging y click fuera slider+boton, verificar hotspots
            if event.type == pygame.MOUSEBUTTONDOWN and event.button==1 and not self.slider_rect.collidepoint(event.pos) and not (hasattr(self, "btn_confirm_rect") and self.btn_confirm_rect.collidepoint(event.pos)):
                # delegar a hotspots
                for hs in self.hotspots:
                    if hs["rect"].collidepoint(event.pos):
                        try: load_sound("clic.wav",0.7).play()
                        except: pass
                        self.on_hotspot_click(hs["id"])
                        break
                return
            return
        # sin slider: comportamiento normal hotspots
        super().handle_event(event)

    def _update_dial_from_mouse(self, mx):
        rel = (mx - self.slider_rect.x) / self.slider_rect.width
        rel = max(0, min(1, rel))
        self.dial_value = int(rel*100)
        # sonido estatica leve al mover?
        # no saturar

    def update(self, dt, mouse_pos):
        super().update(dt, mouse_pos)
        if hasattr(self, "hint_timer") and self.hint_timer>0:
            self.hint_timer-=1
        # actualizar knob rect
        kx = self.slider_rect.x + int(self.slider_rect.width * self.dial_value/100) - 18
        ky = self.slider_rect.centery - 18
        self.knob_rect.x, self.knob_rect.y = kx, ky
        # hover dial knob
        # anim onda si cerca target
        self.near_target = abs(self.dial_value - self.dial_target) < 7

    def draw(self, surf):
        super().draw(surf)
        # dibujar slider si activo
        if getattr(self, "show_slider", False) and not self.show_modal:
            # fondo panel slider
            panel = pygame.Rect(WIDTH//2-320, 300, 640, 180)
            pygame.draw.rect(surf, (25,20,15), panel, border_radius=12)
            inner = panel.inflate(-6,-6)
            pygame.draw.rect(surf, (245,235,210), inner, border_radius=10)
            pygame.draw.rect(surf, GOLD, inner, 2, border_radius=10)
            title = get_font(15, bold=True).render("SINTONIZA LA FRECUENCIA DE PARSIFAL  —  Desliza el dial al punto nítido", True, SEPIA_DARK)
            surf.blit(title, (panel.centerx - title.get_width()//2, panel.y+14))
            sub = get_font(11).render("Busca la zona VERDE (88%). Escucha: la estática desaparece al acercarte.", True, (110,100,85))
            surf.blit(sub, (panel.centerx - sub.get_width()//2, panel.y+34))
            # slider fondo
            slider_bg = self.slider_rect
            # mover slider_rect al panel centro
            # ya esta en 212,380 que coincide con panel.y+... 300+... ok ajustamos?
            # redefinimos posicion relativa al panel
            self.slider_rect.y = panel.y+70
            pygame.draw.rect(surf, (60,55,50), self.slider_rect, border_radius=10)
            pygame.draw.rect(surf, (40,35,30), self.slider_rect, 2, border_radius=10)
            # zona verde target
            target_x = self.slider_rect.x + int(self.slider_rect.width * self.dial_target/100) - 28
            target_rect = pygame.Rect(target_x, self.slider_rect.y-6, 56, 40)
            pygame.draw.rect(surf, (70,150,70, 60) if not self.near_target else (70,150,70, 130), target_rect, border_radius=6)
            pygame.draw.rect(surf, (70,150,70), target_rect, 2, border_radius=6)
            lbl_ok = get_font(9, bold=True).render("NÍTIDO", True, (70,150,70))
            surf.blit(lbl_ok, (target_rect.centerx - lbl_ok.get_width()//2, target_rect.bottom+4))
            # escala marcas
            for i in range(0,101,10):
                x = self.slider_rect.x + int(self.slider_rect.width * i/100)
                h = 8 if i%20==0 else 4
                pygame.draw.line(surf, GOLD, (x, self.slider_rect.bottom+2),(x, self.slider_rect.bottom+2+h),1)
            # knob
            kx = self.slider_rect.x + int(self.slider_rect.width * self.dial_value/100)
            # barra llenado
            fill_w = kx - self.slider_rect.x
            if fill_w>0:
                fill_rect = pygame.Rect(self.slider_rect.x, self.slider_rect.y, fill_w, self.slider_rect.height)
                pygame.draw.rect(surf, (180,150,90), fill_rect, border_radius=10)
                # clip right
                pygame.draw.rect(surf, (60,55,50), (fill_rect.right-10, fill_rect.y, 10, fill_rect.height), border_top_right_radius=10, border_bottom_right_radius=10)
            # knob circulo
            knob_center = (kx, self.slider_rect.centery)
            # sombra
            pygame.draw.circle(surf, (0,0,0, 80), (knob_center[0]+2, knob_center[1]+3), 18)
            pygame.draw.circle(surf, (55,50,45), knob_center, 18)
            pygame.draw.circle(surf, (200,195,180), knob_center, 16, 2)
            pygame.draw.circle(surf, (45,42,38), knob_center, 11)
            pygame.draw.line(surf, (220,50,50), knob_center, (knob_center[0] + 9*math.cos(math.radians(self.dial_value*3.6 -90)), knob_center[1] + 9*math.sin(math.radians(self.dial_value*3.6 -90))), 2)
            pygame.draw.circle(surf, (30,30,30), knob_center, 4)
            # valor
            val_txt = get_font(12, bold=True).render(f"{self.dial_value}%", True, SEPIA_DARK)
            # fondo val
            vr = pygame.Rect(panel.centerx -30, panel.y+110, 60, 20)
            pygame.draw.rect(surf, (255,255,255), vr, border_radius=6)
            pygame.draw.rect(surf, GOLD, vr, 1, border_radius=6)
            surf.blit(val_txt, (panel.centerx - val_txt.get_width()//2, vr.centery - val_txt.get_height()//2))
            # calidad señal visual: barras + estatica
            qual = 100 - abs(self.dial_value - self.dial_target)*4
            qual = max(0, min(100, qual))
            # barras
            bx = panel.x+30
            by = panel.y+142
            for i in range(10):
                h = 6 + i*2
                x = bx + i*12
                active = qual > i*10
                col = (70,150,70) if active else (90,85,75, 100)
                if active and self.near_target:
                    col = (90,180,90)
                pygame.draw.rect(surf, col, (x, by+20-h, 8, h), border_radius=2)
            # etiqueta
            qtxt = get_font(10).render(f"Claridad: {int(qual)}%  {'♪♫ Parsifal nítido!' if self.near_target else '~~~ estática ~~~'}", True, (70,150,70) if self.near_target else (120,110,90))
            surf.blit(qtxt, (bx+140, by+8))
            # boton confirmar
            self.btn_confirm_rect = pygame.Rect(panel.centerx - 90, panel.bottom - 38, 180, 32)
            hover_confirm = self.btn_confirm_rect.collidepoint(pygame.mouse.get_pos()) and not self.show_modal
            col_btn = (70,150,70) if self.near_target and hover_confirm else (70,150,70) if self.near_target else (140,130,110) if hover_confirm else (110,105,95)
            pygame.draw.rect(surf, (30,25,18), self.btn_confirm_rect, border_radius=8)
            inner_btn = self.btn_confirm_rect.inflate(-4,-4)
            pygame.draw.rect(surf, col_btn, inner_btn, border_radius=6)
            pygame.draw.rect(surf, GOLD if hover_confirm else (160,140,110), inner_btn, 2, border_radius=6)
            btn_txt = get_font(12, bold=True).render("CONFIRMAR SINTONÍA  ►", True, CREAM if self.near_target else SEPIA_DARK)
            surf.blit(btn_txt, (self.btn_confirm_rect.centerx - btn_txt.get_width()//2, self.btn_confirm_rect.centery - btn_txt.get_height()//2))
            # hint zona
            if not self.near_target and self.dial_value!=42:
                hint = get_font(10).render("Sigue girando...  Parsifal suena lejano entre chispas.", True, (150,60,60))
                surf.blit(hint, (panel.centerx - hint.get_width()//2, panel.bottom+8))
        # hint overlay
        if hasattr(self, "hint_text") and self.hint_text and self.hint_timer>0:
            box = pygame.Rect(WIDTH//2-300, 520, 600, 36)
            s = pygame.Surface((box.width, box.height), pygame.SRCALPHA)
            s.fill((45,30,15, 220))
            surf.blit(s, box.topleft)
            pygame.draw.rect(surf, GOLD, box, 2, border_radius=8)
            txt = get_font(12).render(self.hint_text, True, CREAM)
            surf.blit(txt, (WIDTH//2 - txt.get_width()//2, box.centery - txt.get_height()//2))

class Nivel3State(NivelState):
    def __init__(self, game):
        super().__init__(game, 3)
        self.cartas = []  # lista de dict con rect, id, texto, orden
        self.slots = []  # 3 slots destino
        self.dragging = None
        self.drag_offset = (0,0)
        self.placed = {}  # slot_idx -> carta id
        self.orden_completo = False

    def _setup_hotspots(self):
        # en este nivel los hotspots son secundarios; las cartas son interactivas directas
        self.hotspots = [
            {"rect": pygame.Rect(60, 580, 200, 56), "id": "teletipo", "nombre": "Teletipo", "desc": HOTSPOTS_DATA[3][0]["desc"]},
            {"rect": pygame.Rect(412, 580, 200, 56), "id": "mesa", "nombre": "★ MESA DEL LOCUTOR ★", "desc": HOTSPOTS_DATA[3][2]["desc"]},
            {"rect": pygame.Rect(760, 580, 200, 56), "id": "microfono_kdka", "nombre": "Micrófono KDKA", "desc": HOTSPOTS_DATA[3][1]["desc"]},
        ]
        # cartas desordenadas
        import random as rnd
        order = [0,1,2]
        rnd.shuffle(order)
        self.cartas = []
        start_x = 120
        for idx, carta_id in enumerate(order):
            data = CARTAS_TELETIPO[carta_id]
            rect = pygame.Rect(start_x + idx*280, 340, 200, 90)
            self.cartas.append({"rect": rect, "orig_rect": rect.copy(), "id": data["id"], "texto": data["texto"], "orden_correcto": data["orden_correcto"], "placed_slot": None})
        # slots destino en mesa
        self.slots = []
        for i in range(3):
            r = pygame.Rect(180 + i*230, 460, 200, 90)
            self.slots.append(r)
        self.dragging = None
        self.placed = {}
        self.orden_completo = False

    def on_hotspot_click(self, hs_id):
        if hs_id == "mesa":
            # verificar orden
            if len(self.placed)==3:
                # comprobar si orden correcto
                correcto = True
                for slot_idx, carta_id in self.placed.items():
                    # buscar carta
                    carta = next(c for c in self.cartas if c["id"]==carta_id)
                    if carta["orden_correcto"] != slot_idx:
                        correcto=False
                        break
                if correcto:
                    self.orden_completo = True
                    self._trigger_question()
                else:
                    self.hint_text = "El orden cronológico no es correcto. ¡Revisa las horas! (18:30 → 20:15 → 22:45)"
                    self.hint_timer = 200
                    try: load_sound("error.wav",0.5).play()
                    except: pass
            else:
                self.hint_text = "Arrastra los 3 cables del teletipo a la mesa en ORDEN CRONOLÓGICO, luego haz clic aquí."
                self.hint_timer = 200
        elif hs_id == "teletipo":
            self.hint_text = "El teletipo escupe papeles desordenados. ¡Arrástralos a la mesa!"
            self.hint_timer = 180
        else:
            self.hint_text = "El locutor Leo Rosenberg espera el guion ordenado antes de abrir el micrófono."
            self.hint_timer = 180

    def handle_event(self, event):
        if self.show_modal:
            super().handle_event(event)
            return
        # drag & drop de cartas
        if event.type == pygame.MOUSEBUTTONDOWN and event.button==1:
            mp = event.pos
            # primero verificar si click en hotspots mesa/teletipo (prioridad?)
            # pero también cartas; decidir: si click en carta, drag; si no, hotspots
            # buscar carta bajo mouse (topmost)
            for carta in reversed(self.cartas):
                if carta["rect"].collidepoint(mp):
                    self.dragging = carta
                    self.drag_offset = (mp[0]-carta["rect"].x, mp[1]-carta["rect"].y)
                    # si estaba colocada, liberarla
                    if carta["placed_slot"] is not None:
                        slot_idx = carta["placed_slot"]
                        if slot_idx in self.placed:
                            del self.placed[slot_idx]
                        carta["placed_slot"] = None
                    # traer al frente
                    self.cartas.remove(carta)
                    self.cartas.append(carta)
                    try: load_sound("clic.wav",0.5).play()
                    except: pass
                    return
            # no carta -> hotspots
            for hs in self.hotspots:
                if hs["rect"].collidepoint(mp):
                    try: load_sound("clic.wav",0.7).play()
                    except: pass
                    self.on_hotspot_click(hs["id"])
                    break
        elif event.type == pygame.MOUSEBUTTONUP and event.button==1:
            if self.dragging:
                # soltar: verificar si sobre slot
                mp = event.pos
                carta = self.dragging
                placed=False
                for idx, slot in enumerate(self.slots):
                    if slot.collidepoint(mp) or slot.colliderect(carta["rect"]):
                        # si slot ocupado, intercambiar? simple: no permitir, devolver
                        if idx in self.placed:
                            # devolver a origen
                            carta["rect"].topleft = carta["orig_rect"].topleft
                        else:
                            # colocar centrado en slot
                            carta["rect"].center = slot.center
                            carta["placed_slot"] = idx
                            self.placed[idx] = carta["id"]
                            try: load_sound("clic.wav",0.6).play()
                            except: pass
                        placed=True
                        break
                if not placed:
                    # si estaba fuera de slots, devolver a origen si no está en slot
                    if carta["placed_slot"] is None:
                        # mantener donde se soltó? permitir flotante pero si no en slot, devolver a origen animado?
                        # lo dejamos donde se soltó pero si no en slot, snap a origen suavemente
                        if not any(slot.colliderect(carta["rect"]) for slot in self.slots):
                            # si está lejos de origen, mantener? para jugabilidad devolvemos si muy lejos
                            pass
                self.dragging=None
                # verificar si todos colocados y feedback visual
        elif event.type == pygame.MOUSEMOTION and self.dragging:
            mp = event.pos
            self.dragging["rect"].x = mp[0] - self.drag_offset[0]
            self.dragging["rect"].y = mp[1] - self.drag_offset[1]

    def update(self, dt, mouse_pos):
        super().update(dt, mouse_pos)
        # actualizar dragging posicion ya en handle
        # hover cartas
        self.hover_carta = None
        if not self.show_modal and not self.dragging:
            for c in self.cartas:
                if c["rect"].collidepoint(mouse_pos):
                    self.hover_carta = c["id"]
                    break
        if hasattr(self, "hint_timer") and self.hint_timer>0:
            self.hint_timer-=1

    def draw(self, surf):
        super().draw(surf)
        # dibujar slots primero
        for idx, slot in enumerate(self.slots):
            # sombra
            shadow = slot.copy(); shadow.y+=4; shadow.x+=2
            pygame.draw.rect(surf, (0,0,0, 70), shadow, border_radius=8)
            # fondo slot
            pygame.draw.rect(surf, (45,38,28), slot, border_radius=8)
            inner = slot.inflate(-4,-4)
            # si ocupado, color diferente
            if idx in self.placed:
                # verificar si orden correcto para color borde
                carta_id = self.placed[idx]
                carta = next(c for c in self.cartas if c["id"]==carta_id)
                correcto = (carta["orden_correcto"]==idx)
                col_bg = (230,250,230) if correcto else (250,230,230) if len(self.placed)==3 else (245,235,210)
                pygame.draw.rect(surf, col_bg, inner, border_radius=6)
                pygame.draw.rect(surf, (70,150,70) if correcto else (170,70,70) if len(self.placed)==3 else GOLD, inner, 2, border_radius=6)
            else:
                pygame.draw.rect(surf, (220,210,185), inner, border_radius=6)
                pygame.draw.rect(surf, GOLD, inner, 2, border_radius=6)
                # guia
                guia = get_font(11, italic=True).render(f"Posición {idx+1}", True, (140,130,115))
                surf.blit(guia, (slot.centerx - guia.get_width()//2, slot.centery - 8))
                # linea punteada
                pygame.draw.rect(surf, (160,140,110), inner, 1, border_radius=6)
            # numero slot
            num = get_font(10, bold=True).render(str(idx+1), True, (90,80,65))
            num_bg = pygame.Rect(slot.x-8, slot.y-8, 22, 22)
            pygame.draw.circle(surf, GOLD, num_bg.center, 11)
            pygame.draw.circle(surf, SEPIA_DARK, num_bg.center, 11, 1)
            surf.blit(num, (num_bg.centerx - num.get_width()//2, num_bg.centery - num.get_height()//2))
        # dibujar cartas
        for carta in self.cartas:
            r = carta["rect"]
            is_hover = (self.hover_carta==carta["id"]) and not self.dragging
            is_drag = (self.dragging is carta)
            # sombra
            shadow = r.copy(); shadow.y+=4; shadow.x+=3
            pygame.draw.rect(surf, (0,0,0, 90), shadow, border_radius=8)
            # cuerpo carta
            col_bg = (255,250,235) if is_hover or is_drag else (245,240,215)
            pygame.draw.rect(surf, (45,38,28), r, border_radius=8)
            inner = r.inflate(-4,-4)
            pygame.draw.rect(surf, col_bg, inner, border_radius=6)
            pygame.draw.rect(surf, GOLD if is_hover else (180,170,150), inner, 2 if is_hover else 1, border_radius=6)
            # lineas texto simulado
            # titulo hora grande
            txt = carta["texto"]
            # dividir en dos lineas: hora y resto
            # txt tiene "18:30 - TEXTO"
            parts = txt.split(" - ",1)
            hora = parts[0]
            resto = parts[1] if len(parts)>1 else ""
            hora_surf = get_font(13, bold=True).render(hora, True, (170,50,50))
            surf.blit(hora_surf, (r.centerx - hora_surf.get_width()//2, r.y+10))
            # resto wrap
            resto_lines = wrap_text(resto, get_font(10, bold=True), r.width-16)
            y = r.y+30
            for line in resto_lines[:2]:
                ls = get_font(10, bold=True).render(line, True, SEPIA_DARK)
                surf.blit(ls, (r.centerx - ls.get_width()//2, y))
                y+=13
            # cinta color segun orden correcto (para debug visual no obvio? usamos color neutro)
            pygame.draw.rect(surf, (200,40,40), (inner.x, inner.bottom-10, inner.width, 8), border_bottom_left_radius=6, border_bottom_right_radius=6)
            # icono drag
            if is_hover or is_drag:
                pygame.draw.circle(surf, GOLD, (r.right-12, r.y+12), 8)
                pygame.draw.circle(surf, SEPIA_DARK, (r.right-12, r.y+12), 8,1)
                arr = get_font(10, bold=True).render("↔", True, SEPIA_DARK)
                surf.blit(arr, (r.right-12 - arr.get_width()//2, r.y+12 - arr.get_height()//2))
            if is_drag:
                # borde resaltado
                pygame.draw.rect(surf, (70,150,70), r, 3, border_radius=8)
        # instrucciones drag
        instr = get_font(11).render("Arrastra los 3 cables a la mesa en orden cronológico (18:30 → 22:45)  y haz clic en MESA DEL LOCUTOR", True, (220,210,180))
        bg = pygame.Surface((instr.get_width()+20, 20), pygame.SRCALPHA)
        bg.fill((15,12,10, 160))
        surf.blit(bg, (WIDTH//2 - instr.get_width()//2 -10, 320-24))
        surf.blit(instr, (WIDTH//2 - instr.get_width()//2, 320-20))
        # progreso
        prog = get_font(11, bold=True).render(f"Cables colocados: {len(self.placed)}/3", True, GOLD if len(self.placed)==3 else CREAM)
        surf.blit(prog, (WIDTH//2 - prog.get_width()//2, 440-14))
        # hint
        if hasattr(self, "hint_text") and self.hint_text and self.hint_timer>0:
            box = pygame.Rect(WIDTH//2-340, 500+56+12, 680, 32)
            s = pygame.Surface((box.width, box.height), pygame.SRCALPHA)
            s.fill((45,30,15, 220))
            surf.blit(s, box.topleft)
            pygame.draw.rect(surf, GOLD, box, 2, border_radius=8)
            txt = get_font(12).render(self.hint_text, True, CREAM)
            surf.blit(txt, (WIDTH//2 - txt.get_width()//2, box.centery - txt.get_height()//2))

class Nivel4State(NivelState):
    def __init__(self, game):
        super().__init__(game, 4)
        self.galena_rect = pygame.Rect(520, 470, 48, 32)  # coincide con dibujo fondo
        self.wire_pos = 0.5  # 0..1 pos sobre piedra
        self.wire_target = 0.62  # punto dulce
        self.dragging_wire = False
        self.near_target = False
        self.solved_slider = False
        self.slider_rect = pygame.Rect(300, 380, 424, 18)
        self.knob_x = 0

    def _setup_hotspots(self):
        self.hotspots = [
            {"rect": pygame.Rect(60, 580, 180, 56), "id": "galena", "nombre": "★ PIEDRA GALENA ★", "desc": HOTSPOTS_DATA[4][0]["desc"]},
            {"rect": pygame.Rect(300, 580, 180, 56), "id": "bobina", "nombre": "Bobina", "desc": HOTSPOTS_DATA[4][1]["desc"]},
            {"rect": pygame.Rect(540, 580, 180, 56), "id": "auricular", "nombre": "Auricular", "desc": HOTSPOTS_DATA[4][2]["desc"]},
        ]

    def enter(self):
        super().enter()
        self.wire_pos = 0.35
        self.solved_slider = False
        self.show_slider = False
        self.hint_text=None
        self.hint_timer=0

    def on_hotspot_click(self, hs_id):
        if hs_id == "galena":
            self.show_slider = True
        elif hs_id == "bobina":
            self._show_hint("La bobina ajusta la longitud de onda, pero el contacto fino está en la GALENA.")
        else:
            self._show_hint("¡Ponte el auricular! Pero primero encuentra el punto sensible de la piedra.")

    def _show_hint(self, text):
        self.hint_text=text
        self.hint_timer=180

    def handle_event(self, event):
        if self.show_modal:
            super().handle_event(event)
            return
        if getattr(self, "show_slider", False) and not self.solved_slider:
            if event.type == pygame.MOUSEBUTTONDOWN and event.button==1:
                if self.slider_rect.collidepoint(event.pos):
                    self.dragging_wire=True
                    self._update_wire(event.pos[0])
                # confirmar boton
                if hasattr(self,"btn_confirm_rect") and self.btn_confirm_rect.collidepoint(event.pos):
                    if abs(self.wire_pos - self.wire_target) < 0.07:
                        self.solved_slider=True
                        try: load_sound("clic.wav",0.7).play()
                        except: pass
                        self._trigger_question()
                    else:
                        self.hint_text="¡Mucho ruido! Sigue moviendo el pelo de gato hasta que la voz se aclare (zona verde)."
                        self.hint_timer=160
                        try: load_sound("estatica.wav",0.5).play()
                        except: pass
                # hotspots si click fuera
                if not self.slider_rect.collidepoint(event.pos) and not (hasattr(self,"btn_confirm_rect") and self.btn_confirm_rect.collidepoint(event.pos)):
                    for hs in self.hotspots:
                        if hs["rect"].collidepoint(event.pos):
                            try: load_sound("clic.wav",0.7).play()
                            except: pass
                            self.on_hotspot_click(hs["id"])
                            break
                return
            elif event.type==pygame.MOUSEBUTTONUP and event.button==1:
                self.dragging_wire=False
            elif event.type==pygame.MOUSEMOTION and self.dragging_wire:
                self._update_wire(event.pos[0])
            return
        super().handle_event(event)

    def _update_wire(self, mx):
        rel = (mx - self.slider_rect.x)/self.slider_rect.width
        rel = max(0, min(1, rel))
        self.wire_pos = rel

    def update(self, dt, mouse_pos):
        super().update(dt, mouse_pos)
        if hasattr(self,"hint_timer") and self.hint_timer>0:
            self.hint_timer-=1
        self.near_target = abs(self.wire_pos - self.wire_target) < 0.07
        # knob x
        self.knob_x = self.slider_rect.x + int(self.slider_rect.width * self.wire_pos)

    def draw(self, surf):
        super().draw(surf)
        # slider galena
        if getattr(self,"show_slider",False) and not self.show_modal:
            panel = pygame.Rect(WIDTH//2-300, 300, 600, 190)
            pygame.draw.rect(surf, (25,20,15), panel, border_radius=12)
            inner = panel.inflate(-6,-6)
            pygame.draw.rect(surf, (245,235,210), inner, border_radius=10)
            pygame.draw.rect(surf, GOLD, inner, 2, border_radius=10)
            title = get_font(14, bold=True).render("AJUSTA EL PELO DE GATO SOBRE LA GALENA — Busca el punto sensible", True, SEPIA_DARK)
            surf.blit(title, (panel.centerx - title.get_width()//2, panel.y+12))
            sub = get_font(11).render("Desliza el alambre hasta la zona VERDE. El audio pasará de estática a voz nítida.", True, (110,100,85))
            surf.blit(sub, (panel.centerx - sub.get_width()//2, panel.y+32))
            # visual piedra
            # dibujar piedra esquemática
            stone_rect = pygame.Rect(panel.centerx-120, panel.y+52, 240, 48)
            pygame.draw.ellipse(surf, (90,95,105), stone_rect)
            pygame.draw.ellipse(surf, (120,125,135), stone_rect.inflate(-10,-8))
            # punto dulce marcado sutil? no, oculto
            # slider
            self.slider_rect.y = panel.y+72
            self.slider_rect.x = panel.x+40
            self.slider_rect.width = panel.width-80
            pygame.draw.rect(surf, (60,55,50), self.slider_rect, border_radius=8)
            pygame.draw.rect(surf, (40,35,30), self.slider_rect, 2, border_radius=8)
            # zona verde
            target_x = self.slider_rect.x + int(self.slider_rect.width * self.wire_target) - 26
            target_rect = pygame.Rect(target_x, self.slider_rect.y-6, 52, 30)
            pygame.draw.rect(surf, (70,150,70, 70) if not self.near_target else (70,150,70, 140), target_rect, border_radius=6)
            pygame.draw.rect(surf, (70,150,70), target_rect, 2, border_radius=6)
            lbl = get_font(8, bold=True).render("PUNTO DULCE", True, (70,150,70))
            surf.blit(lbl, (target_rect.centerx - lbl.get_width()//2, target_rect.bottom+2))
            # fill
            fill_w = self.knob_x - self.slider_rect.x
            if fill_w>0:
                fill_rect = pygame.Rect(self.slider_rect.x, self.slider_rect.y, fill_w, self.slider_rect.height)
                pygame.draw.rect(surf, (180,150,90), fill_rect, border_radius=8)
            # knob (pelo de gato)
            knob = (self.knob_x, self.slider_rect.centery)
            # alambre
            pygame.draw.line(surf, (220,220,210), (knob[0], knob[1]-18),(knob[0], knob[1]+18), 3)
            pygame.draw.circle(surf, (220,220,210), (knob[0], knob[1]-18), 5)
            pygame.draw.circle(surf, (45,45,45), knob, 9)
            pygame.draw.circle(surf, (200,195,180), knob, 7,2)
            pygame.draw.circle(surf, (220,50,50) if self.near_target else (90,90,95), knob, 3)
            # calidad barra + onda
            qual = 100 - abs(self.wire_pos - self.wire_target)*300
            qual = max(0, min(100, qual))
            # ondas visuales
            wave_y = panel.y+118
            wave_x0 = panel.x+30
            # dibujar onda sinusoidal con ruido segun calidad
            # calidad alta = seno limpio, baja = ruido
            for i in range(0, 540, 3):
                x = wave_x0 + i
                # seno base
                y_off = 10*math.sin(i*0.04 + self.t*3) if qual>70 else 14*math.sin(i*0.07 + self.t*5) + random.randint(-4,4) if qual<40 else 12*math.sin(i*0.05+ self.t*4) + random.randint(-2,2)
                # amplitud segun calidad
                amp = qual/100
                y_off *= amp
                # color
                col = (70,150,70) if qual>65 else (200,170,60) if qual>30 else (170,60,60)
                pygame.draw.circle(surf, col, (x, wave_y + int(y_off)), 2)
            # texto calidad
            qtxt = get_font(11, bold=True).render(f"Claridad: {int(qual)}%  {'¡Voz nítida! ¡Se escucha la emisión!' if self.near_target else '~~~ crrrrk ~~~ estática'}", True, (70,150,70) if self.near_target else (150,110,60) if qual>30 else (170,60,60))
            surf.blit(qtxt, (panel.centerx - qtxt.get_width()//2, wave_y+18))
            # boton confirmar
            self.btn_confirm_rect = pygame.Rect(panel.centerx-90, panel.bottom-36, 180, 30)
            hover_confirm = self.btn_confirm_rect.collidepoint(pygame.mouse.get_pos())
            col_btn = (70,150,70) if self.near_target else (110,105,95)
            if hover_confirm and self.near_target:
                col_btn = (90,180,90)
            pygame.draw.rect(surf, (30,25,18), self.btn_confirm_rect, border_radius=8)
            inner_btn = self.btn_confirm_rect.inflate(-4,-4)
            pygame.draw.rect(surf, col_btn, inner_btn, border_radius=6)
            pygame.draw.rect(surf, GOLD if hover_confirm else (160,140,110), inner_btn, 2, border_radius=6)
            btn_txt = get_font(11, bold=True).render("BLOQUEAR CONTACTO  ►", True, CREAM if self.near_target else SEPIA_DARK)
            surf.blit(btn_txt, (self.btn_confirm_rect.centerx - btn_txt.get_width()//2, self.btn_confirm_rect.centery - btn_txt.get_height()//2))
        # hint
        if hasattr(self,"hint_text") and self.hint_text and self.hint_timer>0:
            box = pygame.Rect(WIDTH//2-300, 520, 600, 32)
            s = pygame.Surface((box.width, box.height), pygame.SRCALPHA)
            s.fill((45,30,15, 220))
            surf.blit(s, box.topleft)
            pygame.draw.rect(surf, GOLD, box, 2, border_radius=8)
            txt = get_font(12).render(self.hint_text, True, CREAM)
            surf.blit(txt, (WIDTH//2 - txt.get_width()//2, box.centery - txt.get_height()//2))

# ---------- VICTORIA ----------
class VictoriaState(BaseState):
    def __init__(self, game):
        super().__init__(game)
        self.bg=None
        self.t=0
        self.btn_menu=None
        self.btn_salir=None

    def enter(self):
        self.bg = load_img("fondo_menu.png", (WIDTH,HEIGHT))
        self.btn_menu = Button(pygame.Rect(WIDTH//2-150, 560, 140, 48), "MENÚ", font=get_font(14, bold=True), base_color=GOLD, hover_color=(210,180,110))
        self.btn_salir = Button(pygame.Rect(WIDTH//2+10, 560, 140, 48), "SALIR", font=get_font(14, bold=True), base_color=(90,80,70), hover_color=(120,110,95), text_color=CREAM)
        try:
            pygame.mixer.music.stop()
            load_sound("victoria.wav",0.7).play()
            # delay aplausos
            pygame.time.set_timer(pygame.USEREVENT+1, 800, loops=1)
        except: pass
        try:
            s = load_sound("aplausos.wav",0.6)
            # reproducir con delay via timer? simple play
            # pygame no tiene delay facil, usaremos flag
            self.pending_applause = s
            self.applause_timer = 0.8
        except:
            self.pending_applause=None

    def handle_event(self, event):
        if event.type==pygame.USEREVENT+1:
            try:
                if self.pending_applause: self.pending_applause.play()
            except: pass
        if self.btn_menu.is_clicked(event):
            self.game.signal=100
            self.game.change_state(MENU_INICIAL)
        elif self.btn_salir.is_clicked(event):
            self.game.running=False
        if event.type==pygame.KEYDOWN and event.key==pygame.K_ESCAPE:
            self.game.change_state(MENU_INICIAL)

    def update(self, dt, mouse_pos):
        self.t+=dt
        self.btn_menu.update(mouse_pos)
        self.btn_salir.update(mouse_pos)
        if hasattr(self,"applause_timer") and self.applause_timer>0:
            self.applause_timer-=dt
            if self.applause_timer<=0 and self.pending_applause:
                try: self.pending_applause.play()
                except: pass
                self.pending_applause=None

    def draw(self, surf):
        surf.blit(self.bg,(0,0))
        # panel victoria
        panel = pygame.Rect(WIDTH//2-360, 80, 720, 460)
        shadow = panel.copy(); shadow.x+=6; shadow.y+=6
        pygame.draw.rect(surf, (0,0,0, 90), shadow, border_radius=16)
        pygame.draw.rect(surf, (25,20,15), panel, border_radius=16)
        inner = panel.inflate(-6,-6)
        pygame.draw.rect(surf, (245,235,210), inner, border_radius=14)
        pygame.draw.rect(surf, GOLD, inner, 3, border_radius=14)
        # confetti
        for i in range(30):
            x = (inner.x + 20 + (i*47 + int(self.t*60))% (inner.width-40))
            y = inner.y + 60 + int(30*math.sin(i + self.t*2)) 
            col = [(200,50,50),(70,150,70),(60,90,200),(210,180,80)][i%4]
            pygame.draw.circle(surf, col, (x,y), 4)
        # titulo
        f_title = get_font(36, bold=True)
        t1 = f_title.render("¡SEÑAL COMPLETA!", True, (170,50,40))
        surf.blit(t1, (panel.centerx - t1.get_width()//2, panel.y+22))
        f_sub = get_font(16, italic=True)
        sub = f_sub.render("Has restaurado la cadena de la radiodifusión — 1920", True, (90,80,65))
        surf.blit(sub, (panel.centerx - sub.get_width()//2, panel.y+66))
        pygame.draw.line(surf, GOLD, (panel.x+30, panel.y+88),(panel.right-30, panel.y+88),1)
        # texto logros
        textos = [
            "★  Pittsburgh: El tubo Audión amplifica la voz humana.",
            "★  Buenos Aires: Parsifal cruza el éter desde la azotea del Coliseo.",
            "★  KDKA: El país escucha los resultados electorales en vivo.",
            "★  El hogar: La familia sintoniza la galena. Nace el broadcasting.",
        ]
        y = panel.y+104
        for line in textos:
            # check icono
            pygame.draw.circle(surf, (70,150,70), (inner.x+30, y+10), 10)
            chk = get_font(14, bold=True).render("✓", True, CREAM)
            surf.blit(chk, (inner.x+30 - chk.get_width()//2, y+10 - chk.get_height()//2))
            ls = get_font(13).render(line, True, SEPIA_DARK)
            surf.blit(ls, (inner.x+52, y+4))
            y+=32
        # mensaje final
        pygame.draw.line(surf, GOLD, (panel.x+30, y+6),(panel.right-30, y+6),1)
        y+=16
        msg_lines = [
            "En 1920 la radio dejó de ser un telégrafo sin hilos para convertirse",
            "en un medio de masas. Una sola voz podía llegar a miles de hogares",
            "simultáneamente. Había nacido la cultura del éter.",
        ]
        for line in msg_lines:
            ls = get_font(12, italic=True).render(line, True, (80,70,55))
            surf.blit(ls, (panel.centerx - ls.get_width()//2, y))
            y+=18
        y+=10
        # señal 100%
        sig_bg = pygame.Rect(panel.centerx-130, y, 260, 28)
        pygame.draw.rect(surf, (35,30,25), sig_bg, border_radius=8)
        pygame.draw.rect(surf, GOLD, sig_bg, 2, border_radius=8)
        fill = sig_bg.inflate(-6,-6)
        pygame.draw.rect(surf, (70,150,70), fill, border_radius=6)
        pygame.draw.rect(surf, (90,180,90), (fill.x, fill.y, fill.width, fill.height//2), border_top_left_radius=6, border_top_right_radius=6)
        sig_txt = get_font(14, bold=True).render("CALIDAD DE SEÑAL  100%  —  TRANSMISIÓN NÍTIDA", True, CREAM)
        # centrado dentro barra
        surf.blit(sig_txt, (sig_bg.centerx - sig_txt.get_width()//2, sig_bg.centery - sig_txt.get_height()//2))
        # efecto brillo
        glow = int(80 + 40*math.sin(self.t*3))
        pygame.draw.rect(surf, (70,150,70, 60), sig_bg.inflate(10,10), 2, border_radius=10)
        # botones
        self.btn_menu.draw(surf)
        self.btn_salir.draw(surf)
        # tip
        tip = get_font(10).render(f"Señal final conservada: {self.game.signal}%  •  ¡Gracias por sintonizar la historia!", True, (200,185,150))
        surf.blit(tip, (panel.centerx - tip.get_width()//2, panel.bottom+14))
        # marca de agua
        draw_watermark(surf, alpha=42)

# ---------- GAME OVER ----------
class GameOverState(BaseState):
    def __init__(self, game):
        super().__init__(game)
        self.bg=None
        self.btn_reintentar=None
        self.btn_menu=None
        self.t=0
        self.nivel_perdido=1

    def enter(self):
        self.bg = load_img("fondo_menu.png",(WIDTH,HEIGHT))
        # distorsionar bg a rojo
        self.nivel_perdido = getattr(self.game, "nivel_actual", 1)
        self.btn_reintentar = Button(pygame.Rect(WIDTH//2-160, 500, 150, 50), "REINTENTAR", font=get_font(15, bold=True), base_color=(170,60,60), hover_color=(200,80,80), text_color=CREAM)
        self.btn_menu = Button(pygame.Rect(WIDTH//2+10, 500, 150, 50), "MENÚ", font=get_font(15, bold=True), base_color=(90,80,70), hover_color=(120,110,95), text_color=CREAM)
        try:
            pygame.mixer.music.stop()
            load_sound("error.wav",0.7).play()
        except: pass
        try:
            load_sound("estatica.wav",0.5).play()
        except: pass

    def handle_event(self, event):
        if self.btn_reintentar.is_clicked(event):
            self.game.signal=100
            self.game.change_state(self.nivel_perdido if self.nivel_perdido>=1 else 1)
        elif self.btn_menu.is_clicked(event):
            self.game.signal=100
            self.game.change_state(MENU_INICIAL)
        if event.type==pygame.KEYDOWN and event.key==pygame.K_ESCAPE:
            self.game.change_state(MENU_INICIAL)

    def update(self, dt, mouse_pos):
        self.t+=dt
        self.btn_reintentar.update(mouse_pos)
        self.btn_menu.update(mouse_pos)

    def draw(self, surf):
        surf.blit(self.bg,(0,0))
        # overlay rojo
        red = pygame.Surface((WIDTH,HEIGHT), pygame.SRCALPHA)
        red.fill((120,20,20, 110))
        surf.blit(red,(0,0))
        # estatica animada líneas
        for i in range(0, HEIGHT, 4):
            if random.random()<0.12:
                x = random.randint(0, WIDTH)
                w = random.randint(30, 200)
                pygame.draw.line(surf, (255,255,255, 40), (x,i),(x+w,i),1)
        # panel
        panel = pygame.Rect(WIDTH//2-340, 160, 680, 360)
        shadow = panel.copy(); shadow.x+=6; shadow.y+=6
        pygame.draw.rect(surf, (0,0,0, 90), shadow, border_radius=16)
        pygame.draw.rect(surf, (25,15,15), panel, border_radius=16)
        inner = panel.inflate(-6,-6)
        pygame.draw.rect(surf, (245,235,210), inner, border_radius=14)
        pygame.draw.rect(surf, (170,60,60), inner, 3, border_radius=14)
        # icono
        pygame.draw.circle(surf, (170,60,60), (panel.centerx, panel.y+56), 42)
        pygame.draw.circle(surf, (200,80,80), (panel.centerx, panel.y+56), 38,2)
        icon = get_font(48, bold=True).render("✕", True, CREAM)
        surf.blit(icon, (panel.centerx - icon.get_width()//2, panel.y+56 - icon.get_height()//2+2))
        # titulo
        title = get_font(32, bold=True).render("¡SEÑAL PERDIDA!", True, (170,50,40))
        surf.blit(title, (panel.centerx - title.get_width()//2, panel.y+110))
        sub = get_font(14).render(f"Interferencia total en el Nivel {self.nivel_perdido} — {TITULOS_NIVEL.get(self.nivel_perdido,'')}", True, (90,80,65))
        surf.blit(sub, (panel.centerx - sub.get_width()//2, panel.y+148))
        pygame.draw.line(surf, (170,60,60), (panel.x+30, panel.y+168),(panel.right-30, panel.y+168),1)
        # explicación
        lines = [
            "La calidad de señal ha caído al 0%.",
            "Cada error restó un 20% de claridad. La transmisión se ha",
            "perdido entre chispas y estática.",
            "",
            "Pero la historia de la radio no termina aquí.",
            "Ajusta de nuevo el dial y reintenta.",
        ]
        y = panel.y+182
        for line in lines:
            ls = get_font(13, italic=True if line=="" else False).render(line, True, (80,70,65) if line else (0,0,0))
            if line:
                surf.blit(ls, (panel.centerx - ls.get_width()//2, y))
            y+=20
        # barra 0%
        bar_bg = pygame.Rect(panel.centerx-130, y+8, 260, 22)
        pygame.draw.rect(surf, (35,30,25), bar_bg, border_radius=8)
        pygame.draw.rect(surf, (170,60,60), bar_bg, 2, border_radius=8)
        inner_bar = bar_bg.inflate(-6,-6)
        pygame.draw.rect(surf, (90,30,30), inner_bar, border_radius=6)
        # texto 0%
        txt = get_font(12, bold=True).render("SEÑAL  0%  —  SILENCIO", True, CREAM)
        surf.blit(txt, (bar_bg.centerx - txt.get_width()//2, bar_bg.centery - txt.get_height()//2))
        # scanline
        scan_y = (int(self.t*120) % HEIGHT)
        pygame.draw.line(surf, (255,255,255, 30), (0, scan_y),(WIDTH, scan_y),2)
        # botones
        self.btn_reintentar.draw(surf)
        self.btn_menu.draw(surf)
        # marca de agua
        draw_watermark(surf, alpha=42)
