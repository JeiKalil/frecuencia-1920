# -*- coding: utf-8 -*-
"""
main.py - Punto de entrada para Frecuencia 1920
Ventana 1024x768 centrada, 60 FPS, maquina de estados finitos
"""
import os
import sys
import asyncio

# Centrar ventana (debe hacerse antes de pygame.init / display)
os.environ['SDL_VIDEO_CENTERED'] = '1'
# Evitar escalado
os.environ['SDL_HINT_RENDER_SCALE_QUALITY'] = '0'

import pygame
from states import (
    MENU_INICIAL, NIVEL_1, NIVEL_2, NIVEL_3, NIVEL_4, VICTORIA, GAME_OVER, SPLASH, CREDITS,
    MenuState, Nivel1State, Nivel2State, Nivel3State, Nivel4State, VictoriaState, GameOverState,
    SplashState, CreditsState
)

WIDTH, HEIGHT = 1024, 768
FPS = 60
TITLE = "FRECUENCIA 1920 - La Revolución de la Radio"

class Game:
    def __init__(self):
        pygame.init()
        pygame.mixer.init(frequency=22050, size=-16, channels=2, buffer=512)
        pygame.display.set_caption(TITLE)
        # ventana no escalable
        self.screen = pygame.display.set_mode((WIDTH, HEIGHT), pygame.DOUBLEBUF)
        self.clock = pygame.time.Clock()
        self.running = True
        self.signal = 100  # Calidad de Señal %
        self.nivel_actual = 1
        # cursor personalizado: ocultamos default y dibujamos dial
        pygame.mouse.set_visible(True)
        # estados
        self.states = {
            MENU_INICIAL: MenuState(self),
            NIVEL_1: Nivel1State(self),
            NIVEL_2: Nivel2State(self),
            NIVEL_3: Nivel3State(self),
            NIVEL_4: Nivel4State(self),
            VICTORIA: VictoriaState(self),
            GAME_OVER: GameOverState(self),
            SPLASH: SplashState(self),
            CREDITS: CreditsState(self),
        }
        self.current_state_id = SPLASH
        self.current_state = self.states[self.current_state_id]
        self.current_state.enter()
        # para transiciones suaves
        self.transition_alpha = 0
        self.transition_target = None
        # icon
        try:
            icon = pygame.Surface((32,32), pygame.SRCALPHA)
            pygame.draw.circle(icon, (180,50,40), (16,16), 14)
            pygame.draw.circle(icon, (245,235,210), (16,16), 10,2)
            pygame.draw.circle(icon, (255,220,80), (16,6), 3)
            pygame.display.set_icon(icon)
        except: pass

    def change_state(self, new_state_id):
        # guardar nivel actual para game over
        if new_state_id in (NIVEL_1, NIVEL_2, NIVEL_3, NIVEL_4):
            self.nivel_actual = new_state_id
        # transición con fade simple: cambio inmediato con overlay
        self.current_state.exit()
        self.current_state_id = new_state_id
        self.current_state = self.states[new_state_id]
        # actualizar señal en nuevo nivel si es nivel
        if hasattr(self.current_state, 'signal_bar'):
            self.current_state.signal_bar.set_value(self.signal)
        self.current_state.enter()
        # flash transición
        self.transition_alpha = 255

    async def run(self):
        dt = 0
        while self.running:
            mouse_pos = pygame.mouse.get_pos()
            # eventos
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    self.running = False
                # atajos dev
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_F12:
                        # screenshot
                        try:
                            pygame.image.save(self.screen, f"screenshot_{pygame.time.get_ticks()}.png")
                            print("Screenshot guardado")
                        except: pass
                    # debug: saltar nivel con F1-F4
                    if event.key == pygame.K_F1:
                        self.change_state(NIVEL_1)
                    elif event.key == pygame.K_F2:
                        self.change_state(NIVEL_2)
                    elif event.key == pygame.K_F3:
                        self.change_state(NIVEL_3)
                    elif event.key == pygame.K_F4:
                        self.change_state(NIVEL_4)
                self.current_state.handle_event(event)

            # update
            self.current_state.update(dt, mouse_pos)

            # draw
            self.current_state.draw(self.screen)

            # transicion fade (overlay negro que se desvanece)
            if self.transition_alpha > 0:
                self.transition_alpha = max(0, self.transition_alpha - 700*dt)
                overlay = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
                overlay.fill((0,0,0, int(self.transition_alpha)))
                self.screen.blit(overlay, (0,0))

            # cursor personalizado (dial/mano retro)
            self.draw_custom_cursor(mouse_pos)

            pygame.display.flip()
            dt = self.clock.tick(FPS) / 1000.0
            await asyncio.sleep(0)

        pygame.quit()
        # En pygbag (wasm) no hacer sys.exit forzado para no matar el worker
        try:
            sys.exit(0)
        except SystemExit:
            pass

    def draw_custom_cursor(self, pos):
        # Solo si no estamos en modal? dibujamos siempre un pequeño brillo
        # pero mantenemos cursor del sistema para accesibilidad; añadimos efecto hover
        # dibujar anillo alrededor del cursor cuando está sobre hotspot (opcional)
        try:
            # pequeño punto dorado que sigue al mouse con glow sutil
            # solo si el estado tiene hotspot_hover
            has_hover = False
            cs = self.current_state
            if hasattr(cs, 'hotspot_hover') and cs.hotspot_hover:
                has_hover = True
            elif hasattr(cs, 'hover_carta') and cs.hover_carta is not None:
                has_hover = True
            elif hasattr(cs, 'near_target') and getattr(cs,'near_target', False):
                has_hover = True
            if has_hover:
                # glow
                glow = pygame.Surface((40,40), pygame.SRCALPHA)
                pygame.draw.circle(glow, (255,220,100, 70), (20,20), 16)
                pygame.draw.circle(glow, (255,240,150, 120), (20,20), 10)
                self.screen.blit(glow, (pos[0]-20, pos[1]-20))
                # anillo
                pygame.draw.circle(self.screen, (255,220,100), pos, 12, 2)
                pygame.draw.circle(self.screen, (255,255,255), pos, 3)
        except:
            pass

async def main():
    game = Game()
    await game.run()

if __name__ == "__main__":
    asyncio.run(main())
