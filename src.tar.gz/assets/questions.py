# -*- coding: utf-8 -*-
"""
questions.py - Banco de preguntas historicas para Frecuencia 1920
Cada pregunta corresponde a un nivel.
"""

PREGUNTAS = {
    1: {
        "titulo": "NIVEL 1 - El Laboratorio de Válvulas",
        "subtitulo": "Pittsburgh, EE. UU. - Taller de Frank Conrad, 1920",
        "pregunta": "¿Cuál fue el avance tecnológico que permitió transmitir voz y música continua en 1920 en lugar de solo pulsos Morse?",
        "opciones": [
            ("A", "El telégrafo por cable submarino."),
            ("B", "El tubo de vacío / válvula termoiónica (Audión)."),
            ("C", "La invención de los satélites de baja frecuencia."),
            ("D", "El disco de vinilo de alta fidelidad."),
        ],
        "correcta": 1,  # índice B
        "explicacion_correcta": "¡Correcto! El Audión de Lee De Forest (1906) y su perfeccionamiento permitió amplificar y modular la voz humana. Frank Conrad lo usó para sus primeras emisiones.",
        "explicacion_error": "No es correcto. El tubo de vacío/Audión fue la clave para pasar del chisporroteo Morse a la radiotelefonía.",
        "contexto": "Frank Conrad, ingeniero de Westinghouse, experimentaba en su garaje con un transmisor que superaba las limitaciones del transmisor de chispas."
    },
    2: {
        "titulo": "NIVEL 2 - La Azotea del Teatro Coliseo",
        "subtitulo": "Buenos Aires, Argentina - 27 de agosto de 1920",
        "pregunta": "El 27 de agosto de 1920 en Argentina se realizó una de las primeras transmisiones mundiales abiertas al público general. ¿Qué se transmitió?",
        "opciones": [
            ("A", "Un partido de fútbol internacional."),
            ("B", "El discurso inaugural del presidente de la República."),
            ("C", "La ópera Parsifal de Richard Wagner desde el Teatro Coliseo."),
            ("D", "Un boletín meteorológico para embarcaciones."),
        ],
        "correcta": 2,
        "explicacion_correcta": "¡Exacto! Enrique Susini y 'Los Locos de la Azotea' transmitieron Parsifal con un equipo de 5 vatios desde la azotea del Teatro Coliseo. Solo unas 20 personas con galena pudieron oírla.",
        "explicacion_error": "No fue eso. Fue la ópera Parsifal de Wagner, considerada la primera transmisión de arte programada para público general en el mundo.",
        "contexto": "Con solo 5 vatios de potencia, un micrófono colgado sobre el escenario y una antena improvisada, hicieron historia."
    },
    3: {
        "titulo": "NIVEL 3 - La Sala de Redacción KDKA",
        "subtitulo": "Pittsburgh - 2 de noviembre de 1920 - Noche electoral",
        "pregunta": "¿Qué hito periodístico convirtió a la estación KDKA el 2 de noviembre de 1920 en el referente del broadcasting comercial?",
        "opciones": [
            ("A", "La narración en vivo del primer combate de boxeo profesional."),
            ("B", "La transmisión en tiempo real de los resultados electorales entre Harding y Cox."),
            ("C", "El primer radionovela dramatizado de ciencia ficción."),
            ("D", "El primer anuncio publicitario de comida en conserva."),
        ],
        "correcta": 1,
        "explicacion_correcta": "¡Correcto! KDKA transmitió el recuento Harding vs Cox. Fue la primera vez que miles de hogares supieron el ganador por radio antes que por el periódico.",
        "explicacion_error": "No. KDKA se consagró al transmitir en vivo los resultados de las elecciones presidenciales Harding-Cox, inaugurando el periodismo radial.",
        "contexto": "Westinghouse instaló un teletipo directo en el estudio. Leo Rosenberg anunció los retornos cada pocos minutos ante una audiencia masiva."
    },
    4: {
        "titulo": "NIVEL 4 - El Receptor de Galena",
        "subtitulo": "El Hogar en 1920 - La sala familiar",
        "pregunta": "¿Qué concepto comunicativo nació formalmente en 1920 al enviar señales desde una estación hacia miles de receptores desconocidos en sus hogares?",
        "opciones": [
            ("A", "Podcasting."),
            ("B", "Telegrafía de punto a punto."),
            ("C", "Broadcasting (Radiodifusión masiva)."),
            ("D", "Streaming analógico."),
        ],
        "correcta": 2,
        "explicacion_correcta": "¡Brillante! 'Broadcasting', término tomado de la agricultura (esparcir semillas al viento), definió la nueva era: un emisor, miles de receptores anónimos. Nació la cultura de masas.",
        "explicacion_error": "No es ese. El término es Broadcasting: la idea revolucionaria de emitir para una audiencia masiva, invisible y dispersa.",
        "contexto": "La radio de galena, sin baterías, con su 'pelo de gato' sobre la piedra, llevó por primera vez voces y música a la intimidad del hogar."
    },
}

# Datos para mecanicas drag & drop nivel 3 y narrativa
CARTAS_TELETIPO = [
    {"id": 0, "texto": "18:30 - CIERRE DE MESAS EN OHIO", "orden_correcto": 0},
    {"id": 1, "texto": "20:15 - HARDING TOMA VENTAJA EN PENNSYLVANIA", "orden_correcto": 1},
    {"id": 2, "texto": "22:45 - KDKA ANUNCIA: HARDING PRESIDENTE ELECTO", "orden_correcto": 2},
]

# Textos de hotspots por nivel
HOTSPOTS_DATA = {
    1: [
        {"id": "chispa", "nombre": "Transmisor de Chispas (Obsoleto)", "desc": "Genera solo pulsos ásperos. No sirve para voz. Necesitas algo que AMPLIFIQUE ondas continuas."},
        {"id": "audion", "nombre": "Válvula Termoiónica - Tubo Audión", "desc": "¡El corazón del futuro! Amplifica señales débiles y permite modular la voz. Frank Conrad lo considera CLAVE."},
        {"id": "antena", "nombre": "Antena Exterior", "desc": "Sin antena no hay alcance. Pero primero debes elegir el CORAZÓN del transmisor."},
    ],
    2: [
        {"id": "transmisor5w", "nombre": "Transmisor 5 Vatios", "desc": "Pequeño pero poderoso. Los Locos lo armaron con restos de un barco de guerra."},
        {"id": "microfono", "nombre": "Micrófono de Carbón", "desc": "Colgado sobre el escenario del Coliseo. Captará a los cantantes de Parsifal."},
        {"id": "dial", "nombre": "Dial de Sintonía", "desc": "Debes encontrar la frecuencia exacta. ¡La ópera no espera!"},
    ],
    3: [
        {"id": "teletipo", "nombre": "Teletipo de Noticias", "desc": "Escupe resultados a medida que llegan. ¡Hay que ordenarlos!"},
        {"id": "microfono_kdka", "nombre": "Micrófono KDKA", "desc": "Leo Rosenberg espera tu guion ordenado para salir al aire."},
        {"id": "mesa", "nombre": "Mesa del Locutor", "desc": "Aquí se ordena la historia antes de contarla."},
    ],
    4: [
        {"id": "galena", "nombre": "Piedra de Galena", "desc": "Cristal de sulfuro de plomo. El 'pelo de gato' debe tocar el punto sensible."},
        {"id": "bobina", "nombre": "Bobina de Sintonía", "desc": "Desliza el contacto para sintonizar. Cada milímetro cambia el mundo."},
        {"id": "auricular", "nombre": "Auricular de Baquelita", "desc": "Póntelo. Si sintonizas bien, oirás la historia."},
    ],
}
