# -*- coding: utf-8 -*-
"""
ui.py - Componentes visuales retro para Frecuencia 1920
Botones, modales, barra de señal, tipografia y helpers
"""
import pygame
import math

# Paleta
CREAM = (245, 230, 200)
SEPIA_DARK = (45, 30, 15)
SEPIA_MED = (112, 85, 55)
SEPIA_LIGHT = (210, 180, 140)
GOLD = (180, 150, 80)
GOLD_HOVER = (210, 180, 110)
BROWN_DARK = (60, 35, 15)
VERDE_OK = (70, 150, 70)
ROJO_ERR = (170, 60, 60)
NEGRO = (15, 12, 10)
BLANCO = (250, 245, 235)

def get_font(size, bold=False, italic=False):
    # Intenta cargar fuente retro; fallback a SysFont
    # Pygame no trae fuente sepia, usamos serif/monospace para look vintage
    try:
        # Intentar fuente del sistema tipo serif
        return pygame.font.SysFont("Georgia, serif, Times New Roman", size, bold=bold, italic=italic)
    except:
        return pygame.font.SysFont(None, size, bold=bold)

def get_mono_font(size, bold=False):
    try:
        return pygame.font.SysFont("Consolas, Courier New, monospace", size, bold=bold)
    except:
        return pygame.font.SysFont("monospace", size, bold=bold)

def wrap_text(text, font, max_width):
    """Divide texto en lineas que no excedan max_width"""
    words = text.split(" ")
    lines = []
    cur = ""
    for w in words:
        test = cur + (" " if cur else "") + w
        if font.size(test)[0] <= max_width:
            cur = test
        else:
            if cur:
                lines.append(cur)
            cur = w
            # si una sola palabra es muy larga, forzar corte
            if font.size(cur)[0] > max_width:
                # corte duro por caracteres
                tmp = ""
                for ch in w:
                    if font.size(tmp+ch)[0] <= max_width:
                        tmp += ch
                    else:
                        lines.append(tmp)
                        tmp = ch
                cur = tmp
    if cur:
        lines.append(cur)
    return lines

class Button:
    def __init__(self, rect, text, font=None, base_color=(140,120,85), hover_color=(170,145,100), text_color=SEPIA_DARK, border_radius=10, sound=None):
        self.rect = pygame.Rect(rect)
        self.text = text
        self.font = font or get_font(18, bold=True)
        self.base_color = base_color
        self.hover_color = hover_color
        self.text_color = text_color
        self.border_radius = border_radius
        self.hovered = False
        self.pressed = False
        self.enabled = True
        self.sound = sound
        # para animacion
        self.scale = 1.0

    def update(self, mouse_pos):
        if not self.enabled:
            self.hovered = False
            return
        self.hovered = self.rect.collidepoint(mouse_pos)

    def draw(self, surf):
        col = self.hover_color if self.hovered else self.base_color
        if not self.enabled:
            col = (100, 95, 85)
        # sombra
        shadow = self.rect.copy()
        shadow.y += 3
        pygame.draw.rect(surf, (0,0,0, 60), shadow, border_radius=self.border_radius)
        # cuerpo
        # para alpha sombra usamos surface temporal si es necesario; simplificamos sin alpha
        pygame.draw.rect(surf, (30,25,18), self.rect, border_radius=self.border_radius)
        inner = self.rect.inflate(-4, -4)
        pygame.draw.rect(surf, col, inner, border_radius=self.border_radius-2)
        # highlight
        pygame.draw.line(surf, (255,255,255, 40), (inner.x+10, inner.y+6), (inner.right-10, inner.y+6), 1)
        # borde hover
        if self.hovered and self.enabled:
            pygame.draw.rect(surf, GOLD, inner, 2, border_radius=self.border_radius-2)
        # texto
        txt_surf = self.font.render(self.text, True, self.text_color if self.enabled else (80,75,68))
        # centrar
        tx = self.rect.centerx - txt_surf.get_width()//2
        ty = self.rect.centery - txt_surf.get_height()//2
        surf.blit(txt_surf, (tx, ty))

    def is_clicked(self, event):
        if not self.enabled:
            return False
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            if self.rect.collidepoint(event.pos):
                if self.sound:
                    try: self.sound.play()
                    except: pass
                return True
        return False

    def is_hovered(self):
        return self.hovered

class SignalBar:
    """Barra de Calidad de Señal 0-100%"""
    def __init__(self, rect, value=100):
        self.rect = pygame.Rect(rect)
        self.value = value  # 0-100
        self.target_value = value
        self.anim = float(value)

    def set_value(self, v):
        self.target_value = max(0, min(100, v))
    
    def update(self):
        # animacion suave
        diff = self.target_value - self.anim
        if abs(diff) > 0.1:
            self.anim += diff * 0.12
        else:
            self.anim = float(self.target_value)
        self.value = int(round(self.anim))

    def draw(self, surf, font=None):
        font = font or get_font(14, bold=True)
        # fondo
        pygame.draw.rect(surf, (35,30,25), self.rect, border_radius=6)
        pygame.draw.rect(surf, (90,80,65), self.rect, 2, border_radius=6)
        # calcular color segun valor
        v = self.anim
        if v > 60:
            col = (70, 150, 80)
            col2 = (100, 190, 110)
        elif v > 30:
            col = (200, 170, 60)
            col2 = (230, 200, 90)
        else:
            col = (190, 60, 60)
            col2 = (220, 90, 90)
        # interior
        inner = self.rect.inflate(-6, -6)
        # barra progreso
        w = int(inner.width * (v/100.0))
        if w > 0:
            bar_rect = pygame.Rect(inner.x, inner.y, w, inner.height)
            # gradiente simple: dos rects
            pygame.draw.rect(surf, col, bar_rect, border_radius=4)
            h2 = bar_rect.height//2
            pygame.draw.rect(surf, col2, (bar_rect.x, bar_rect.y, bar_rect.width, h2), border_top_left_radius=4, border_top_right_radius=4)
            # segmentos vintage tipo LED
            for i in range(1, 5):
                x = inner.x + int(inner.width * i/5)
                if x < bar_rect.right:
                    pygame.draw.line(surf, (35,30,25), (x, inner.y), (x, inner.bottom), 2)
            # brillo
            pygame.draw.line(surf, (255,255,255, 60), (bar_rect.x+4, bar_rect.y+2), (bar_rect.right-4, bar_rect.y+2), 1)
        # texto
        label = font.render(f"SEÑAL  {int(v)}%", True, CREAM)
        surf.blit(label, (self.rect.x, self.rect.y - 20))
        # icono onda
        # dibujar mini onda en lado derecho
        ox = self.rect.right + 8
        oy = self.rect.centery
        for i in range(3):
            r = 4 + i*4
            alpha = 255 if v > i*33 else 80
            col_w = (200,180,140) if v > i*33 else (80,75,70)
            pygame.draw.circle(surf, col_w, (ox, oy), r, 1)

class Modal:
    """Modal de pregunta con fondo semitransparente y caja vintage"""
    def __init__(self, pregunta_data, font_title=None, font_body=None):
        self.data = pregunta_data
        self.font_title = font_title or get_font(22, bold=True)
        self.font_sub = get_font(14, italic=True)
        self.font_body = font_body or get_font(17)
        self.font_opt = get_font(16)
        self.font_small = get_font(13)
        self.result = None  # 'correct' / 'incorrect' / None
        self.selected = None
        self.buttons = []
        self.close_button = None
        self.feedback_timer = 0
        self.show_feedback = False
        self._build_buttons()

    def _build_buttons(self):
        # 4 botones de opciones verticales
        base_y = 300
        for idx, (letra, texto) in enumerate(self.data["opciones"]):
            rect = pygame.Rect(112, base_y + idx*68, 800, 56)
            # texto recortado para boton: "A. texto..."
            display = f"{letra}.  {texto}"
            btn = Button(rect, display, font=self.font_opt, base_color=(230,220,190), hover_color=(255,240,210), text_color=SEPIA_DARK)
            self.buttons.append(btn)
        # boton continuar tras feedback
        self.continue_btn = Button(pygame.Rect(412, 620, 200, 48), "CONTINUAR  >", font=get_font(16, bold=True), base_color=GOLD, hover_color=GOLD_HOVER, text_color=SEPIA_DARK)

    def handle_event(self, event, mouse_pos):
        if self.show_feedback:
            if self.continue_btn.is_clicked(event):
                return "continue"
            self.continue_btn.update(mouse_pos)
            return None
        else:
            for btn in self.buttons:
                btn.update(mouse_pos)
                if btn.is_clicked(event):
                    idx = self.buttons.index(btn)
                    correcta = self.data["correcta"]
                    if idx == correcta:
                        self.result = "correct"
                        btn.base_color = (70, 150, 70)
                        btn.hover_color = (90, 170, 90)
                    else:
                        self.result = "incorrect"
                        btn.base_color = (170, 70, 70)
                        btn.hover_color = (190, 80, 80)
                        # resaltar correcta
                        self.buttons[correcta].base_color = (70, 150, 70)
                    self.selected = idx
                    self.show_feedback = True
                    return self.result
        return None

    def update(self, mouse_pos):
        if self.show_feedback:
            self.continue_btn.update(mouse_pos)
        else:
            for b in self.buttons:
                b.update(mouse_pos)

    def draw(self, surf):
        # overlay oscuro
        overlay = pygame.Surface((1024,768), pygame.SRCALPHA)
        overlay.fill((0,0,0, 160))
        surf.blit(overlay, (0,0))
        # caja principal
        box_rect = pygame.Rect(80, 70, 864, 640)
        # sombra
        shadow = box_rect.copy()
        shadow.x += 6
        shadow.y += 6
        pygame.draw.rect(surf, (0,0,0, 90), shadow, border_radius=14)
        pygame.draw.rect(surf, (35,30,22), box_rect, border_radius=14)
        inner = box_rect.inflate(-6, -6)
        pygame.draw.rect(surf, (245, 235, 210), inner, border_radius=12)
        # borde doble
        pygame.draw.rect(surf, (180,150,90), inner, 2, border_radius=12)
        inner2 = inner.inflate(-10, -10)
        pygame.draw.rect(surf, (180,150,90, 60), inner2, 1, border_radius=10)
        # header decorativo
        header_rect = pygame.Rect(inner.x, inner.y, inner.width, 72)
        pygame.draw.rect(surf, (45,38,28), header_rect, border_top_left_radius=12, border_top_right_radius=12)
        # linea dorada
        pygame.draw.line(surf, GOLD, (inner.x+20, header_rect.bottom-1), (inner.right-20, header_rect.bottom-1), 2)
        # titulo
        title = self.font_title.render(self.data["titulo"], True, GOLD)
        surf.blit(title, (inner.centerx - title.get_width()//2, inner.y + 14))
        sub = self.font_sub.render(self.data["subtitulo"], True, (200,185,150))
        surf.blit(sub, (inner.centerx - sub.get_width()//2, inner.y + 42))
        # contexto (si no hay feedback)
        if not self.show_feedback:
            ctx_lines = wrap_text(self.data.get("contexto",""), self.font_small, inner.width-60)
            y = 155
            for line in ctx_lines:
                ls = self.font_small.render(line, True, (90,80,65))
                surf.blit(ls, (inner.centerx - ls.get_width()//2, y))
                y += 16
            # pregunta
            q_lines = wrap_text(self.data["pregunta"], self.font_body, inner.width-80)
            y = 195
            for line in q_lines:
                ls = self.font_body.render(line, True, SEPIA_DARK)
                # negrita simulada: render doble?
                surf.blit(ls, (inner.centerx - ls.get_width()//2, y))
                y += 22
            # separador
            pygame.draw.line(surf, (180,150,90), (inner.centerx-120, y+4), (inner.centerx+120, y+4), 1)
            # botones
            for b in self.buttons:
                b.draw(surf)
            # tip
            tip = self.font_small.render("Haz clic en la respuesta que consideres correcta.  (-20% de señal si fallas)", True, (120,110,90))
            surf.blit(tip, (inner.centerx - tip.get_width()//2, 610))
        else:
            # feedback
            y = 165
            if self.result == "correct":
                # icono check
                pygame.draw.circle(surf, (70,150,70), (inner.centerx, y), 36)
                pygame.draw.circle(surf, (95,180,95), (inner.centerx, y), 32, 2)
                chk = get_font(36, bold=True).render("✓", True, BLANCO)
                surf.blit(chk, (inner.centerx - chk.get_width()//2, y - chk.get_height()//2 + 2))
                y += 55
                msg = get_font(22, bold=True).render("¡CORRECTO!", True, (50,120,50))
                surf.blit(msg, (inner.centerx - msg.get_width()//2, y))
                y += 34
                exp = self.data["explicacion_correcta"]
                col = (50,90,50)
            else:
                pygame.draw.circle(surf, (170,60,60), (inner.centerx, y), 36)
                pygame.draw.circle(surf, (200,80,80), (inner.centerx, y), 32, 2)
                chk = get_font(36, bold=True).render("✕", True, BLANCO)
                surf.blit(chk, (inner.centerx - chk.get_width()//2, y - chk.get_height()//2 + 2))
                y += 55
                msg = get_font(22, bold=True).render("RESPUESTA INCORRECTA", True, (160,50,50))
                surf.blit(msg, (inner.centerx - msg.get_width()//2, y))
                y += 34
                exp = self.data["explicacion_error"]
                # mostrar correcta
                letra_correcta, txt_correcta = self.data["opciones"][self.data["correcta"]]
                corr = f"La respuesta correcta era {letra_correcta}: {txt_correcta}"
                corr_lines = wrap_text(corr, get_font(14, bold=True), inner.width-80)
                for line in corr_lines:
                    ls = get_font(14, bold=True).render(line, True, (90,70,30))
                    surf.blit(ls, (inner.centerx - ls.get_width()//2, y))
                    y += 18
                y += 8
                col = (130, 50, 50)
            y += 6
            exp_lines = wrap_text(exp, get_font(15), inner.width-90)
            for line in exp_lines:
                ls = get_font(15).render(line, True, col)
                surf.blit(ls, (inner.centerx - ls.get_width()//2, y))
                y += 20
            # efecto señal
            if self.result == "correct":
                sig = get_font(14, bold=True).render("SEÑAL ESTABLE  +  TRANSMISIÓN NÍTIDA", True, (70,130,70))
            else:
                sig = get_font(14, bold=True).render("¡INTERFERENCIA!  -20%  CALIDAD DE SEÑAL", True, (170,60,60))
            surf.blit(sig, (inner.centerx - sig.get_width()//2, 580))
            self.continue_btn.draw(surf)

def draw_hotspot(surf, rect, text, hovered=False, font=None, icon=None):
    font = font or get_font(14, bold=True)
    # hotspot con glow al hover
    col_bg = (245,235,210) if hovered else (230,220,190)
    col_border = GOLD if hovered else (160,140,110)
    # sombra
    shadow = rect.copy()
    shadow.y += 3
    shadow.x += 2
    pygame.draw.rect(surf, (0,0,0, 50), shadow, border_radius=8)
    pygame.draw.rect(surf, (45,38,28), rect, border_radius=8)
    inner = rect.inflate(-4,-4)
    pygame.draw.rect(surf, col_bg, inner, border_radius=6)
    pygame.draw.rect(surf, col_border, inner, 2 if hovered else 1, border_radius=6)
    # pulso decorativo al hover
    if hovered:
        glow = pygame.Surface((rect.width+20, rect.height+20), pygame.SRCALPHA)
        pygame.draw.rect(glow, (255,220,100, 30), (0,0,rect.width+20, rect.height+20), border_radius=12)
        surf.blit(glow, (rect.x-10, rect.y-10))
        # punto pulsante
        pulse_r = 6 + int(2*math.sin(pygame.time.get_ticks()*0.008))
        pygame.draw.circle(surf, (220,50,50), (rect.right-16, rect.y+14), pulse_r)
        pygame.draw.circle(surf, (255,80,80), (rect.right-16, rect.y+14), 3)
    # texto centrado
    txt = font.render(text, True, SEPIA_DARK)
    # manejar texto largo: wrap a 2 lineas max
    if txt.get_width() > rect.width - 16:
        words = text.split(" ")
        lines=[]
        cur=""
        for w in words:
            test = cur+" "+w if cur else w
            if font.size(test)[0] <= rect.width-18:
                cur=test
            else:
                lines.append(cur)
                cur=w
        if cur: lines.append(cur)
        # centrar vertical
        total_h = len(lines)*16
        start_y = rect.centery - total_h//2
        for i, line in enumerate(lines[:2]):
            ls = font.render(line, True, SEPIA_DARK)
            surf.blit(ls, (rect.centerx - ls.get_width()//2, start_y + i*16))
    else:
        surf.blit(txt, (rect.centerx - txt.get_width()//2, rect.centery - txt.get_height()//2))

def draw_top_bar(surf, nivel_num, titulo_nivel, signal_bar, font=None):
    font = font or get_font(16, bold=True)
    # barra superior semitransparente
    bar = pygame.Rect(0,0,1024,56)
    # fondo oscuro con alpha simulado
    overlay = pygame.Surface((1024,56), pygame.SRCALPHA)
    overlay.fill((15,12,10, 190))
    surf.blit(overlay, (0,0))
    pygame.draw.line(surf, GOLD, (0,56),(1024,56),2)
    # logo / titulo
    title = font.render(f"NIVEL {nivel_num} — {titulo_nivel}", True, GOLD)
    surf.blit(title, (18, 10))
    # subtitulo pequeño
    subfont = get_font(11)
    sub = subfont.render("FRECUENCIA  1920  •  La Revolución de la Radio", True, (180,165,140))
    surf.blit(sub, (18, 32))
    # barra señal a la derecha
    signal_bar.rect.x = 1024 - 320
    signal_bar.rect.y = 18
    signal_bar.draw(surf, get_font(12, bold=True))
